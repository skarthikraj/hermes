# Workflow Builder (React + Vite)

A simple workflow builder UI powered by React Flow. Upload sample data, run a simulated workflow (filter and calculate), preview results, and download CSV.

## Prerequisites
- Node.js 18+ recommended

## Install
```bash
npm install
```

## Run (development)
```bash
npm run dev
```

Open the printed local URL (typically `http://localhost:5173`).

### Backend API
- The backend runs at `http://localhost:8080`.
- You can override the base URL by creating `.env` with:
  ```
  VITE_API_BASE_URL=http://localhost:8080
  ```


## Build
```bash
npm run build
npm run preview
```

## Notes
- Tailwind styles are loaded via CDN in `index.html` for convenience.
- The app now calls the backend for upload and execution. Ensure the backend is running on port 8080.
- Results preview appears at the bottom after execution; you can download the CSV from the Output node.


