import React, { useMemo, useState, useCallback, useEffect } from 'react';
import ReactFlow, {
  MiniMap,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  addEdge,
  Handle,
  Position,
  ReactFlowProvider,
  useReactFlow,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { Upload, Filter, Calculator, Play, Download } from 'lucide-react';
import { uploadFile, executeWorkflowApi } from './api.js';
import logo from '../logo.png';

const DRAG_TYPE = 'application/reactflow';

// Alteryx-ish palette (MVP)
const PALETTE_TOOLS = [
  {
    kind: 'dataSource',
    toolType: 'input',
    label: 'Input Data',
    description: 'Load Excel/CSV into the workflow',
    icon: Upload,
  },
  {
    kind: 'transform',
    toolType: 'select',
    label: 'Select',
    description: 'Choose/rename columns (not executed yet)',
    icon: Calculator,
  },
  {
    kind: 'transform',
    toolType: 'filter',
    label: 'Filter',
    description: 'Keep rows by condition',
    icon: Filter,
    defaultConfig: { column: 'sales', operator: '>', value: '1000' },
  },
  {
    kind: 'transform',
    toolType: 'calculate',
    label: 'Formula',
    description: 'Create/modify a column',
    icon: Calculator,
    defaultConfig: {
      newColumn: 'total_revenue',
      expression: `"sales"::DOUBLE * "quantity"::DOUBLE`,
    },
  },
  {
    kind: 'transform',
    toolType: 'sort',
    label: 'Sort',
    description: 'Sort rows (not executed yet)',
    icon: Calculator,
  },
  {
    kind: 'transform',
    toolType: 'summarize',
    label: 'Summarize',
    description: 'Group + aggregate (not executed yet)',
    icon: Calculator,
  },
  {
    kind: 'output',
    toolType: 'output',
    label: 'Output Data',
    description: 'Download results as CSV',
    icon: Download,
  },
];

function Palette() {
  return (
    <div className="w-72 border-r bg-gray-50 p-3 overflow-auto">
      <div className="text-xs font-semibold text-gray-500 mb-2">PALETTE</div>
      <div className="space-y-2">
        {PALETTE_TOOLS.map((tool) => {
          const Icon = tool.icon;
          return (
            <div
              key={`${tool.kind}:${tool.toolType}`}
              className="cursor-grab active:cursor-grabbing rounded border bg-white p-3 shadow-sm hover:bg-gray-50"
              draggable
              onDragStart={(event) => {
                event.dataTransfer.setData(DRAG_TYPE, JSON.stringify(tool));
                event.dataTransfer.effectAllowed = 'move';
              }}
            >
              <div className="flex items-start gap-2">
                <Icon className="w-4 h-4 text-gray-700 mt-0.5" />
                <div className="min-w-0">
                  <div className="text-sm font-semibold">{tool.label}</div>
                  <div className="text-xs text-gray-600">{tool.description}</div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 text-xs text-gray-500">
        Drag a tool onto the canvas.
        <br />
        Connect nodes left → right like Alteryx.
      </div>
    </div>
  );
}

function makeId(prefix) {
  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function summarizeTransform(data) {
  const t = (data?.type || '').toLowerCase();
  const cfg = data?.config || {};
  if (t === 'filter') {
    const col = cfg.column || '(column)';
    const op = cfg.operator || '(op)';
    const val = cfg.value ?? '(value)';
    return `${col} ${op} ${val}`;
  }
  if (t === 'calculate') {
    const col = cfg.newColumn || '(new_column)';
    const expr = cfg.expression || '(expression)';
    return `${col} = ${expr}`;
  }
  return data?.description || '';
}

function NodeInspector({ selectedNode, sourceColumns, onUpdateNodeData }) {
  if (!selectedNode) {
    return (
      <div className="w-80 border-l bg-gray-50 p-3 overflow-auto">
        <div className="text-xs font-semibold text-gray-500 mb-2">CONFIG</div>
        <div className="text-sm text-gray-600">
          Click a node to configure it.
        </div>
      </div>
    );
  }

  const node = selectedNode;
  const title = node.data?.label || node.type;

  if (node.type === 'dataSource') {
    const cols = sourceColumns.length ? sourceColumns.join(', ') : '—';
    return (
      <div className="w-80 border-l bg-gray-50 p-3 overflow-auto">
        <div className="text-xs font-semibold text-gray-500 mb-2">CONFIG</div>
        <div className="text-sm font-semibold mb-2">{title}</div>
        <div className="text-xs text-gray-700">
          <div className="mb-1">
            <span className="font-semibold">File:</span>{' '}
            {node.data?.fileName || 'No file selected'}
          </div>
          <div className="mb-1">
            <span className="font-semibold">Rows:</span>{' '}
            {node.data?.rowCount ?? '—'}
          </div>
          <div className="mb-1">
            <span className="font-semibold">Columns:</span> {cols}
          </div>
        </div>
        <div className="mt-3 text-xs text-gray-500">
          Use the file picker inside the node to upload.
        </div>
      </div>
    );
  }

  if (node.type === 'output') {
    return (
      <div className="w-80 border-l bg-gray-50 p-3 overflow-auto">
        <div className="text-xs font-semibold text-gray-500 mb-2">CONFIG</div>
        <div className="text-sm font-semibold mb-2">{title}</div>
        <div className="text-xs text-gray-700">
          Download is enabled after execution.
        </div>
      </div>
    );
  }

  // transform
  const t = (node.data?.type || '').toLowerCase();
  const cfg = node.data?.config || {};
  const allowedOps = ['=', '!=', '<>', '>', '>=', '<', '<=', 'LIKE', 'ILIKE'];

  if (t === 'filter') {
    const column = cfg.column || '';
    const operator = cfg.operator || '=';
    const value = cfg.value ?? '';
    return (
      <div className="w-80 border-l bg-gray-50 p-3 overflow-auto">
        <div className="text-xs font-semibold text-gray-500 mb-2">CONFIG</div>
        <div className="text-sm font-semibold mb-2">{title}</div>

        <div className="space-y-3">
          <div>
            <div className="text-xs font-semibold text-gray-600 mb-1">
              Column
            </div>
            {sourceColumns.length > 0 ? (
              <select
                className="w-full rounded border p-2 text-sm"
                value={column}
                onChange={(e) => {
                  const next = { ...cfg, column: e.target.value };
                  onUpdateNodeData(node.id, {
                    config: next,
                    description: summarizeTransform({ ...node.data, config: next }),
                  });
                }}
              >
                <option value="" disabled>
                  Select a column…
                </option>
                {sourceColumns.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            ) : (
              <input
                className="w-full rounded border p-2 text-sm"
                placeholder="e.g. sales"
                value={column}
                onChange={(e) => {
                  const next = { ...cfg, column: e.target.value };
                  onUpdateNodeData(node.id, {
                    config: next,
                    description: summarizeTransform({ ...node.data, config: next }),
                  });
                }}
              />
            )}
          </div>

          <div>
            <div className="text-xs font-semibold text-gray-600 mb-1">
              Operator
            </div>
            <select
              className="w-full rounded border p-2 text-sm"
              value={operator}
              onChange={(e) => {
                const next = { ...cfg, operator: e.target.value };
                onUpdateNodeData(node.id, {
                  config: next,
                  description: summarizeTransform({ ...node.data, config: next }),
                });
              }}
            >
              {allowedOps.map((op) => (
                <option key={op} value={op}>
                  {op}
                </option>
              ))}
            </select>
            <div className="mt-1 text-[11px] text-gray-500">
              For LIKE/ILIKE, use % wildcards (e.g. %foo%).
            </div>
          </div>

          <div>
            <div className="text-xs font-semibold text-gray-600 mb-1">
              Value
            </div>
            <input
              className="w-full rounded border p-2 text-sm"
              placeholder="e.g. 1000"
              value={value}
              onChange={(e) => {
                const next = { ...cfg, value: e.target.value };
                onUpdateNodeData(node.id, {
                  config: next,
                  description: summarizeTransform({ ...node.data, config: next }),
                });
              }}
            />
          </div>
        </div>
      </div>
    );
  }

  if (t === 'calculate') {
    const newColumn = cfg.newColumn || '';
    const expression = cfg.expression || '';
    return (
      <div className="w-80 border-l bg-gray-50 p-3 overflow-auto">
        <div className="text-xs font-semibold text-gray-500 mb-2">CONFIG</div>
        <div className="text-sm font-semibold mb-2">{title}</div>

        <div className="space-y-3">
          <div>
            <div className="text-xs font-semibold text-gray-600 mb-1">
              New column
            </div>
            <input
              className="w-full rounded border p-2 text-sm"
              placeholder="e.g. total_revenue"
              value={newColumn}
              onChange={(e) => {
                const next = { ...cfg, newColumn: e.target.value };
                onUpdateNodeData(node.id, {
                  config: next,
                  description: summarizeTransform({ ...node.data, config: next }),
                });
              }}
            />
          </div>

          <div>
            <div className="text-xs font-semibold text-gray-600 mb-1">
              Expression (DuckDB SQL)
            </div>
            <textarea
              className="w-full rounded border p-2 text-sm font-mono"
              rows={5}
              placeholder={`Example:\n"sales"::DOUBLE * "quantity"::DOUBLE`}
              value={expression}
              onChange={(e) => {
                const next = { ...cfg, expression: e.target.value };
                onUpdateNodeData(node.id, {
                  config: next,
                  description: summarizeTransform({ ...node.data, config: next }),
                });
              }}
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-80 border-l bg-gray-50 p-3 overflow-auto">
      <div className="text-xs font-semibold text-gray-500 mb-2">CONFIG</div>
      <div className="text-sm font-semibold mb-2">{title}</div>
      <div className="text-xs text-gray-700">
        This tool is UI-only right now. Execution is supported for Filter and
        Formula only.
      </div>
    </div>
  );
}

// Custom Node Components
const DataSourceNode = ({ data }) => {
  return (
    <div className="w-[240px] h-[140px] px-4 py-3 shadow-lg rounded-lg bg-blue-50 border-2 border-blue-500 flex flex-col">
      <Handle type="source" position={Position.Right} className="w-3 h-3" />
      <div className="flex items-center gap-2 mb-2">
        <Upload className="w-4 h-4 text-blue-600" />
        <div className="font-bold text-sm">Data Source</div>
      </div>
      <div className="text-xs text-gray-600 flex-1 min-h-0">
        <div className="font-semibold truncate" title={data.fileName || ''}>
          {data.fileName || 'No file selected'}
        </div>
        {data.rowCount && <div className="mt-1">{data.rowCount} rows loaded</div>}
      </div>
      <input
        type="file"
        accept=".xlsx,.xls,.csv"
        onChange={data.onFileUpload}
        className="mt-2 text-xs w-full"
      />
    </div>
  );
};

const TransformNode = ({ data }) => {
  const summary = summarizeTransform(data);
  return (
    <div className="w-[240px] h-[140px] px-4 py-3 shadow-lg rounded-lg bg-green-50 border-2 border-green-500 flex flex-col">
      <Handle type="target" position={Position.Left} className="w-3 h-3" />
      <Handle type="source" position={Position.Right} className="w-3 h-3" />
      <div className="flex items-center gap-2 mb-2">
        {data.type === 'filter' ? (
          <Filter className="w-4 h-4 text-green-600" />
        ) : (
          <Calculator className="w-4 h-4 text-green-600" />
        )}
        <div className="font-bold text-sm truncate" title={data.label}>
          {data.label}
        </div>
      </div>
      <div className="text-xs text-gray-600 flex-1 min-h-0">
        <div className="line-clamp-2" title={summary}>
          {summary}
        </div>
        {data.rowCount && <div className="mt-1">{data.rowCount} rows</div>}
        {data.unsupported && (
          <div className="mt-1 text-amber-700">
            Not executable yet (UI only)
          </div>
        )}
      </div>
    </div>
  );
};

const OutputNode = ({ data }) => {
  return (
    <div className="w-[240px] h-[140px] px-4 py-3 shadow-lg rounded-lg bg-purple-50 border-2 border-purple-500 flex flex-col">
      <Handle type="target" position={Position.Left} className="w-3 h-3" />
      <div className="flex items-center gap-2 mb-2">
        <Download className="w-4 h-4 text-purple-600" />
        <div className="font-bold text-sm">Output</div>
      </div>
      <div className="text-xs text-gray-600 flex-1 min-h-0">
        {data.rowCount ? `${data.rowCount} rows` : 'Ready to export'}
      </div>
      {data.results && (
        <button
          onClick={data.onDownload}
          className="mt-2 px-2 py-1 bg-purple-500 text-white text-xs rounded hover:bg-purple-600"
        >
          Download Results
        </button>
      )}
    </div>
  );
};

const nodeTypes = {
  dataSource: DataSourceNode,
  transform: TransformNode,
  output: OutputNode,
};

function buildLinearChain(nodes, edges) {
  const nodeById = new Map(nodes.map((n) => [n.id, n]));
  const out = new Map();
  edges.forEach((e) => {
    if (!out.has(e.source)) out.set(e.source, []);
    out.get(e.source).push(e.target);
  });

  const source = nodes.find((n) => n.type === 'dataSource');
  const output = nodes.find((n) => n.type === 'output');
  if (!source) {
    return { error: 'Add an Input Data node first.' };
  }
  if (!output) {
    return { error: 'Add an Output Data node.' };
  }

  const chain = [source.id];
  const visited = new Set(chain);
  let cur = source.id;
  while (cur !== output.id) {
    const nexts = out.get(cur) || [];
    if (nexts.length === 0) {
      return { error: 'Connect your nodes from Input → … → Output.' };
    }
    if (nexts.length > 1) {
      return { error: 'Branches are not supported yet. Keep it linear for now.' };
    }
    const next = nexts[0];
    if (!nodeById.has(next)) {
      return { error: 'Found an edge to a missing node.' };
    }
    if (visited.has(next)) {
      return { error: 'Cycle detected. Workflows must be acyclic.' };
    }
    chain.push(next);
    visited.add(next);
    cur = next;
  }
  return { sourceId: source.id, outputId: output.id, chainIds: chain };
}

function transformationsFromChain(nodes, chainIds) {
  const nodeById = new Map(nodes.map((n) => [n.id, n]));
  const transformations = [];
  const unsupported = [];

  for (const id of chainIds) {
    const node = nodeById.get(id);
    if (!node) continue;
    if (node.type !== 'transform') continue;

    const t = (node.data?.type || '').toLowerCase();
    if (t === 'filter' || t === 'calculate') {
      transformations.push({
        type: t,
        config: node.data?.config || {},
        _nodeId: node.id,
      });
    } else {
      unsupported.push(node.data?.label || node.id);
    }
  }
  return { transformations, unsupported };
}

const WorkflowAppInner = () => {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [isExecuting, setIsExecuting] = useState(false);
  const [results, setResults] = useState(null);
  const [selectedNodeId, setSelectedNodeId] = useState(null);
  const [resultsLimit, setResultsLimit] = useState(50);
  const [resultsPanelHeight, setResultsPanelHeight] = useState(240);
  const [isResizingResults, setIsResizingResults] = useState(false);
  const { screenToFlowPosition } = useReactFlow();

  const selectedNode = useMemo(
    () => nodes.find((n) => n.id === selectedNodeId) || null,
    [nodes, selectedNodeId]
  );

  const sourceColumns = useMemo(() => {
    const src = nodes.find((n) => n.type === 'dataSource' && n.data?.fileData?.length);
    const firstRow = src?.data?.fileData?.[0];
    if (!firstRow) return [];
    return Object.keys(firstRow);
  }, [nodes]);

  const onConnect = useCallback(
    (params) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  const handleFileUpload = async (nodeId, event) => {
    const file = event.target.files[0];
    if (!file) return;

    try {
      const resp = await uploadFile(file);
      setNodes((nds) =>
        nds.map((node) => {
          if (node.id === nodeId) {
            return {
              ...node,
              data: {
                ...node.data,
                fileName: file.name,
                rowCount: resp.rowCount,
                fileData: resp.data
              },
            };
          }
          return node;
        })
      );
    } catch (err) {
      alert('Upload failed: ' + (err?.message || err));
    }
  };

  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();
      const raw = event.dataTransfer.getData(DRAG_TYPE);
      if (!raw) return;

      let tool;
      try {
        tool = JSON.parse(raw);
      } catch {
        return;
      }

      const position = screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      });

      const id = makeId(tool.kind);
      if (tool.kind === 'dataSource') {
        setNodes((nds) => [
          ...nds,
          {
            id,
            type: 'dataSource',
            position,
            data: {
              label: tool.label,
              fileName: null,
              rowCount: null,
              fileData: null,
              onFileUpload: (e) => handleFileUpload(id, e),
            },
          },
        ]);
        return;
      }

      if (tool.kind === 'output') {
        setNodes((nds) => [
          ...nds,
          {
            id,
            type: 'output',
            position,
            data: {
              label: tool.label,
              rowCount: null,
              results: null,
              onDownload: handleDownload,
            },
          },
        ]);
        return;
      }

      // transform
      const initialConfig = tool.defaultConfig || {};
      setNodes((nds) => [
        ...nds,
        {
          id,
          type: 'transform',
          position,
          data: {
            label: tool.label,
            description: tool.description,
            type: tool.toolType,
            rowCount: null,
            config: initialConfig,
            unsupported: tool.toolType !== 'filter' && tool.toolType !== 'calculate',
          },
        },
      ]);
    },
    [screenToFlowPosition, setNodes]
  );

  const onUpdateNodeData = useCallback(
    (nodeId, patch) => {
      setNodes((nds) =>
        nds.map((n) => {
          if (n.id !== nodeId) return n;
          return { ...n, data: { ...n.data, ...patch } };
        })
      );
    },
    [setNodes]
  );

  const executeWorkflow = async () => {
    setIsExecuting(true);

    try {
      const chain = buildLinearChain(nodes, edges);
      if (chain.error) {
        alert(chain.error);
        setIsExecuting(false);
        return;
      }

      const sourceNode = nodes.find((n) => n.id === chain.sourceId);
      if (!sourceNode?.data?.fileData) {
        alert('Upload a file in the Input Data node first.');
        setIsExecuting(false);
        return;
      }

      const { transformations, unsupported } = transformationsFromChain(nodes, chain.chainIds);
      if (unsupported.length > 0) {
        alert(
          `These tools are UI-only for now and will be skipped on execution:\n- ${unsupported.join(
            '\n- '
          )}`
        );
      }

      const payload = {
        fileData: sourceNode.data.fileData,
        transformations: transformations.map((t) => ({
          type: t.type,
          config: t.config,
        })),
      };
      const resp = await executeWorkflowApi(payload);

      const rowCount = resp.rowCount || (resp.data ? resp.data.length : 0);
      setNodes((nds) =>
        nds.map((node) => {
          if (node.type === 'transform') {
            return { ...node, data: { ...node.data, rowCount } };
          }
          if (node.type === 'output') {
            return { ...node, data: { ...node.data, rowCount, results: resp.data } };
          }
          return node;
        })
      );
      setResults(resp.data);
      setResultsLimit(50);
    } catch (error) {
      alert('Error executing workflow: ' + error.message);
    } finally {
      setIsExecuting(false);
    }
  };

  const handleDownload = () => {
    if (!results) return;
    
    const csv = [
      Object.keys(results[0]).join(','),
      ...results.map(row => Object.values(row).join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'workflow_results.csv';
    a.click();
  };

  useEffect(() => {
    if (!isResizingResults) return;

    let startY = 0;
    let startH = 0;

    const onMove = (e) => {
      // Dragging the handle UP increases height
      const dy = startY - e.clientY;
      const minH = 120;
      const maxH = Math.max(minH, Math.floor(window.innerHeight * 0.75));
      const next = Math.max(minH, Math.min(maxH, startH + dy));
      setResultsPanelHeight(next);
    };

    const onUp = () => {
      setIsResizingResults(false);
    };

    // We stash the start values on the window while resizing starts
    // (set in onPointerDown) to keep the effect logic simple.
    startY = window.__hermes_resultsResizeStartY || 0;
    startH = window.__hermes_resultsResizeStartH || resultsPanelHeight;

    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    window.addEventListener('mouseleave', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
      window.removeEventListener('mouseleave', onUp);
    };
  }, [isResizingResults, resultsPanelHeight]);

  return (
    <div className="w-full h-screen flex flex-col">
      <div className="bg-[#f6f7f8] text-gray-900 border-b p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img
            src={logo}
            alt="Project Hermes"
            className="w-14 h-14 object-contain"
          />
          <h1 className="text-xl font-bold">Project Hermes</h1>
        </div>
        <button
          onClick={executeWorkflow}
          disabled={isExecuting}
          style={{ borderColor: '#fd5108' }}
          className="flex items-center gap-2 px-4 py-2 rounded border text-black bg-transparent hover:bg-[#fd5108]/10 focus:outline-none focus:ring-0 focus:border-[#fd5108] disabled:border-gray-300 disabled:text-gray-400 disabled:hover:bg-transparent disabled:cursor-not-allowed"
        >
          <Play className="w-4 h-4" />
          {isExecuting ? 'Executing...' : 'Run Workflow'}
        </button>
      </div>
      
      <div className="flex-1 flex min-h-0">
        <Palette />
        <div className="flex-1" onDrop={onDrop} onDragOver={onDragOver}>
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            nodeTypes={nodeTypes}
            onNodeClick={(_, node) => setSelectedNodeId(node.id)}
            onPaneClick={() => setSelectedNodeId(null)}
            fitView
          >
            <Controls />
            <MiniMap />
            <Background variant="dots" gap={12} size={1} />
          </ReactFlow>
        </div>
        <NodeInspector
          selectedNode={selectedNode}
          sourceColumns={sourceColumns}
          onUpdateNodeData={onUpdateNodeData}
        />
      </div>

      {results && (
        <div
          className="bg-white border-t overflow-hidden flex flex-col"
          style={{ height: resultsPanelHeight }}
        >
          <div
            className="h-2 bg-gray-100 hover:bg-gray-200 cursor-row-resize select-none"
            title="Drag to resize"
            onMouseDown={(e) => {
              // Store start values for the resizing effect
              window.__hermes_resultsResizeStartY = e.clientY;
              window.__hermes_resultsResizeStartH = resultsPanelHeight;
              setIsResizingResults(true);
            }}
          />
          <div className="p-4 overflow-auto min-h-0">
          <div className="flex items-center justify-between gap-3 mb-2">
            <h3 className="font-bold">Results</h3>
            <div className="flex items-center gap-2 text-xs">
              <div className="text-gray-600">
                Showing{' '}
                <span className="font-semibold">
                  {Math.min(results.length, resultsLimit === Infinity ? results.length : resultsLimit)}
                </span>{' '}
                of <span className="font-semibold">{results.length}</span>
              </div>
              <button
                onClick={() => setResultsLimit(50)}
                className="px-2 py-1 rounded border bg-white hover:bg-gray-50"
                disabled={resultsLimit === 50}
              >
                50
              </button>
              <button
                onClick={() => setResultsLimit(200)}
                className="px-2 py-1 rounded border bg-white hover:bg-gray-50"
                disabled={resultsLimit === 200}
              >
                200
              </button>
              <button
                onClick={() => setResultsLimit(Infinity)}
                className="px-2 py-1 rounded border bg-white hover:bg-gray-50"
                disabled={resultsLimit === Infinity}
              >
                All
              </button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-xs">
              <thead>
                <tr className="bg-gray-100">
                  {results.length > 0 &&
                    Object.keys(results[0]).map((key) => (
                      <th key={key} className="px-2 py-1 text-left">
                        {key}
                      </th>
                    ))}
                </tr>
              </thead>
              <tbody>
                {results
                  .slice(0, resultsLimit === Infinity ? results.length : resultsLimit)
                  .map((row, idx) => (
                  <tr key={idx} className="border-b">
                    {Object.values(row).map((val, i) => (
                      <td key={i} className="px-2 py-1">{val}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          </div>
        </div>
      )}
    </div>
  );
};

const WorkflowApp = () => (
  <ReactFlowProvider>
    <WorkflowAppInner />
  </ReactFlowProvider>
);

export default WorkflowApp;


