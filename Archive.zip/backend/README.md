## Hermes Go Backend

Endpoints:
- `GET /health` — health check
- `POST /api/upload` — multipart form field `file` (Excel `.xlsx`); returns parsed rows as JSON
- `POST /api/execute` — accepts JSON with `fileData` and `transformations`; runs in-memory DuckDB transformations and returns results

### Run locally
Prereqs: Go 1.22+

```bash
cd /Users/karthik/Documents/Hermes/backend
go mod tidy
go run .
```

Server starts on `http://localhost:8080`.

### /api/execute request shape
```json
{
  "fileData": [
    {"colA": "1", "colB": "2"}
  ],
  "transformations": [
    {
      "type": "filter",
      "config": { "column": "colA", "operator": ">", "value": "0" }
    },
    {
      "type": "calculate",
      "config": { "newColumn": "sumAB", "expression": "\"colA\"::DOUBLE + \"colB\"::DOUBLE" }
    }
  ]
}
```

Notes:
- All Excel values are initially loaded as strings; cast inside expressions as needed.
- Filter `operator` is validated against a small allowlist: `=, <>, !=, >, >=, <, <=, LIKE, ILIKE`.


