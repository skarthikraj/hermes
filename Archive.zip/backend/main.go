package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"sort"
	"strings"

	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"
	_ "github.com/duckdb/duckdb-go/v2"
	"github.com/xuri/excelize/v2"
)

type WorkflowRequest struct {
	FileData        []map[string]interface{} `json:"fileData"`
	Transformations []Transformation         `json:"transformations"`
}

type Transformation struct {
	Type   string                 `json:"type"`
	Config map[string]interface{} `json:"config"`
}

type WorkflowResponse struct {
	Success  bool                       `json:"success"`
	Data     []map[string]interface{}   `json:"data,omitempty"`
	RowCount int                        `json:"rowCount,omitempty"`
	Error    string                     `json:"error,omitempty"`
	Meta     map[string]map[string]any  `json:"meta,omitempty"`
}

var db *sql.DB

func main() {
	// Initialize DuckDB (in-memory)
	var err error
	db, err = sql.Open("duckdb", "")
	if err != nil {
		log.Fatal("Failed to open DuckDB:", err)
	}
	defer db.Close()

	// Ensure DB is reachable
	if err := db.Ping(); err != nil {
		log.Fatal("DuckDB ping failed:", err)
	}

	// Echo Router
	e := echo.New()
	e.HideBanner = true
	e.Use(middleware.Recover())

	// CORS
	e.Use(middleware.CORSWithConfig(middleware.CORSConfig{
		AllowOrigins: []string{"*"},
		AllowMethods: []string{http.MethodGet, http.MethodPost, http.MethodPut, http.MethodDelete, http.MethodOptions},
		AllowHeaders: []string{"*"},
	}))

	// Routes
	e.GET("/health", handleHealth)
	e.POST("/api/upload", handleUpload)
	e.POST("/api/execute", handleExecute)

	log.Println("Server starting on :8080")
	e.Logger.Fatal(e.Start(":8080"))
}

func handleHealth(c echo.Context) error {
	return respondJSON(c, http.StatusOK, WorkflowResponse{Success: true})
}

func handleUpload(c echo.Context) error {
	fileHeader, err := c.FormFile("file")
	if err != nil {
		return respondError(c, "Failed to read form file", err)
	}
	file, err := fileHeader.Open()
	if err != nil {
		return respondError(c, "Failed to open uploaded file", err)
	}
	defer file.Close()

	// Open directly from stream
	f, err := excelize.OpenReader(file)
	if err != nil {
		return respondError(c, "Failed to read Excel", err)
	}
	defer f.Close()

	sheets := f.GetSheetList()
	if len(sheets) == 0 {
		return respondError(c, "No sheets found in Excel", nil)
	}

	rows, err := f.GetRows(sheets[0])
	if err != nil {
		return respondError(c, "Failed to read rows", err)
	}

	data := excelToJSON(rows)
	return respondJSON(c, http.StatusOK, WorkflowResponse{
		Success:  true,
		Data:     data,
		RowCount: len(data),
	})
}

func handleExecute(c echo.Context) error {
	var req WorkflowRequest
	if err := json.NewDecoder(c.Request().Body).Decode(&req); err != nil {
		return respondError(c, "Invalid request body", err)
	}

	tableName := "workflow_data"
	if err := createTableFromData(tableName, req.FileData); err != nil {
		return respondError(c, "Failed to create table", err)
	}

	currentTable := tableName
	for i, t := range req.Transformations {
		nextTable := fmt.Sprintf("transform_%d", i)
		var err error
		switch strings.ToLower(t.Type) {
		case "filter":
			err = applyFilter(currentTable, nextTable, t.Config)
		case "calculate":
			err = applyCalculation(currentTable, nextTable, t.Config)
		default:
			err = fmt.Errorf("unknown transformation type: %s", t.Type)
		}
		if err != nil {
			return respondError(c, "Transformation failed", err)
		}
		currentTable = nextTable
	}

	results, err := queryTable(currentTable)
	if err != nil {
		return respondError(c, "Failed to fetch results", err)
	}

	return respondJSON(c, http.StatusOK, WorkflowResponse{
		Success:  true,
		Data:     results,
		RowCount: len(results),
	})
}

func createTableFromData(tableName string, data []map[string]interface{}) error {
	_, _ = db.Exec(fmt.Sprintf(`DROP TABLE IF EXISTS %s`, qIdent(tableName)))
	if len(data) == 0 {
		return fmt.Errorf("no data provided")
	}

	// Stable column order from first row keys
	columns := sortedKeys(data[0])

	// Create table (all as VARCHAR for simplicity)
	var colDefs []string
	for _, col := range columns {
		colDefs = append(colDefs, fmt.Sprintf(`%s VARCHAR`, qIdent(col)))
	}
	createSQL := fmt.Sprintf(`CREATE TABLE %s (%s)`, qIdent(tableName), strings.Join(colDefs, ", "))
	if _, err := db.Exec(createSQL); err != nil {
		return err
	}

	// Prepare insert with stable column list
	var placeholders []string
	for range columns {
		placeholders = append(placeholders, "?")
	}
	insertSQL := fmt.Sprintf(
		`INSERT INTO %s (%s) VALUES (%s)`,
		qIdent(tableName),
		joinQuoted(columns, ", "),
		strings.Join(placeholders, ", "),
	)
	stmt, err := db.Prepare(insertSQL)
	if err != nil {
		return err
	}
	defer stmt.Close()

	for _, row := range data {
		values := make([]any, len(columns))
		for i, col := range columns {
			values[i] = toString(row[col])
		}
		if _, err := stmt.Exec(values...); err != nil {
			return err
		}
	}
	return nil
}

func applyFilter(inputTable, outputTable string, config map[string]interface{}) error {
	// Expected config: column (string), operator (string), value (any)
	col, _ := config["column"].(string)
	op, _ := config["operator"].(string)
	val := config["value"]

	if col == "" || op == "" {
		return fmt.Errorf("filter requires 'column' and 'operator'")
	}
	opNorm := strings.ToUpper(strings.TrimSpace(op))
	if !isAllowedOperator(opNorm) {
		return fmt.Errorf("operator not allowed: %s", op)
	}

	// Data is stored as VARCHAR. For numeric comparisons (>, >=, <, <=) we must cast,
	// otherwise DuckDB performs lexicographic (string) comparison and results look wrong.
	switch opNorm {
	case ">", ">=", "<", "<=":
		query := fmt.Sprintf(
			`CREATE TABLE %s AS SELECT * FROM %s WHERE TRY_CAST(%s AS DOUBLE) %s CAST(? AS DOUBLE)`,
			qIdent(outputTable), qIdent(inputTable), qIdent(col), opNorm,
		)
		_, err := db.Exec(query, toString(val))
		return err
	default:
		query := fmt.Sprintf(
			`CREATE TABLE %s AS SELECT * FROM %s WHERE %s %s ?`,
			qIdent(outputTable), qIdent(inputTable), qIdent(col), opNorm,
		)
		_, err := db.Exec(query, toString(val))
		return err
	}
}

func applyCalculation(inputTable, outputTable string, config map[string]interface{}) error {
	// Expected config: newColumn (string), expression (string)
	newCol, _ := config["newColumn"].(string)
	expr, _ := config["expression"].(string)
	if newCol == "" || expr == "" {
		return fmt.Errorf("calculate requires 'newColumn' and 'expression'")
	}
	// Note: expression is injected into SQL; ensure trusted input if exposed publicly.
	query := fmt.Sprintf(
		`CREATE TABLE %s AS SELECT *, (%s) AS %s FROM %s`,
		qIdent(outputTable), expr, qIdent(newCol), qIdent(inputTable),
	)
	_, err := db.Exec(query)
	return err
}

func queryTable(tableName string) ([]map[string]interface{}, error) {
	rows, err := db.Query(fmt.Sprintf(`SELECT * FROM %s`, qIdent(tableName)))
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	cols, err := rows.Columns()
	if err != nil {
		return nil, err
	}

	var results []map[string]interface{}
	for rows.Next() {
		values := make([]any, len(cols))
		ptrs := make([]any, len(cols))
		for i := range values {
			ptrs[i] = &values[i]
		}
		if err := rows.Scan(ptrs...); err != nil {
			return nil, err
		}
		row := make(map[string]interface{}, len(cols))
		for i, c := range cols {
			row[c] = values[i]
		}
		results = append(results, row)
	}
	return results, nil
}

func excelToJSON(rows [][]string) []map[string]interface{} {
	if len(rows) < 1 {
		return nil
	}
	headers := rows[0]
	var data []map[string]interface{}
	for _, r := range rows[1:] {
		item := make(map[string]interface{}, len(headers))
		for i, h := range headers {
			if i < len(r) {
				item[h] = r[i]
			} else {
				item[h] = ""
			}
		}
		data = append(data, item)
	}
	return data
}

func respondError(c echo.Context, message string, err error) error {
	msg := message
	if err != nil {
		msg = fmt.Sprintf("%s: %v", message, err)
	}
	return c.JSON(http.StatusBadRequest, WorkflowResponse{Success: false, Error: msg})
}

func respondJSON(c echo.Context, status int, payload WorkflowResponse) error {
	return c.JSON(status, payload)
}

func qIdent(ident string) string {
	// Quote SQL identifiers using DuckDB double-quote rules; escape internal quotes
	escaped := strings.ReplaceAll(ident, `"`, `""`)
	return `"` + escaped + `"`
}

func joinQuoted(strs []string, sep string) string {
	parts := make([]string, len(strs))
	for i, s := range strs {
		parts[i] = qIdent(s)
	}
	return strings.Join(parts, sep)
}

func sortedKeys(m map[string]interface{}) []string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	return keys
}

func isAllowedOperator(op string) bool {
	switch strings.ToUpper(strings.TrimSpace(op)) {
	case "=", "<>", "!=", ">", ">=", "<", "<=", "LIKE", "ILIKE":
		return true
	default:
		return false
	}
}

func toString(v interface{}) string {
	switch t := v.(type) {
	case nil:
		return ""
	case string:
		return t
	case fmt.Stringer:
		return t.String()
	default:
		return fmt.Sprintf("%v", v)
	}
}


