const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080';

export async function uploadFile(file) {
  const form = new FormData();
  form.append('file', file);
  const res = await fetch(`${API_BASE}/api/upload`, {
    method: 'POST',
    body: form,
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || 'Upload failed');
  }
  return res.json();
}

export async function executeWorkflowApi(payload) {
  const res = await fetch(`${API_BASE}/api/execute`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || 'Execution failed');
  }
  return res.json();
}

export async function planCopilotApi(payload) {
  const res = await fetch(`${API_BASE}/api/copilot/plan`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const text = await res.text();
    try {
      const parsed = JSON.parse(text);
      throw new Error(parsed?.error || parsed?.message || text || 'Copilot planning failed');
    } catch {
      throw new Error(text || 'Copilot planning failed');
    }
  }
  const data = await res.json();
  if (data?.success === false) {
    throw new Error(data?.error || 'Copilot planning failed');
  }
  return data;
}

export { API_BASE };

export async function publishWorkflowApi(document) {
  const res = await fetch(`${API_BASE}/api/workflows/publish`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ document }),
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.success) {
    throw new Error(data?.error || 'Publish failed');
  }
  return data;
}

export async function getPublishedWorkflowApi(publishedId) {
  const res = await fetch(`${API_BASE}/api/published/${publishedId}`, {
    method: 'GET',
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.success) {
    throw new Error(data?.error || 'Failed to load published workflow');
  }
  return data;
}

export async function startPublishedWorkflowRunApi(publishedId) {
  const res = await fetch(`${API_BASE}/api/published/${publishedId}/start`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({}),
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.success) {
    throw new Error(data?.error || 'Failed to start workflow');
  }
  return data;
}

export async function getRunApi(runId) {
  const res = await fetch(`${API_BASE}/api/runs/${runId}`, { method: 'GET' });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.success) {
    throw new Error(data?.error || 'Failed to load run');
  }
  return data;
}

export async function submitHumanTaskApi(taskId, answers) {
  const res = await fetch(`${API_BASE}/api/tasks/${taskId}/submit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ answers: answers || {} }),
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.success) {
    throw new Error(data?.error || 'Failed to submit task');
  }
  return data;
}


