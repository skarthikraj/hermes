package main

import (
	"database/sql"
	"fmt"
	"net"
	"net/url"
	"os"
	"strconv"
	"strings"
)

// We store published workflows + run state in Postgres.
// DuckDB remains for per-user data processing only.

type runtimeSQLDialect string

const (
	runtimeDialectDuckDB  runtimeSQLDialect = "duckdb"
	runtimeDialectPostgres runtimeSQLDialect = "postgres"
)

func openRuntimeStoreFromEnv() (*sql.DB, runtimeSQLDialect, error) {
	dsn := strings.TrimSpace(os.Getenv("DATABASE_URL"))
	if dsn == "" {
		// Backward-compatible local fallback
		db, err := sql.Open("duckdb", "hermes_runtime.duckdb")
		if err != nil {
			return nil, "", err
		}
		return db, runtimeDialectDuckDB, nil
	}

	// Allow the user to keep password outside the URL and inject it via DB_PWD.
	// Supports DATABASE_URL containing DB_PWD / $DB_PWD / ${DB_PWD}.
	//
	// Note: if your password contains special URL characters (especially '@'),
	// embedding it directly into a postgresql:// URL can break parsing unless it is percent-encoded.
	pwd := os.Getenv("DB_PWD")
	if pwd != "" {
		dsn = strings.ReplaceAll(dsn, "${DB_PWD}", pwd)
		dsn = strings.ReplaceAll(dsn, "$DB_PWD", pwd)
		dsn = strings.ReplaceAll(dsn, "DB_PWD", pwd)
	}

	normalized := normalizePostgresDSN(dsn)

	// Uses pgx stdlib driver name "pgx" (imported for side-effects in runtime_postgres_driver.go)
	db, err := sql.Open("pgx", normalized)
	if err != nil {
		return nil, "", fmt.Errorf("open postgres: %w", err)
	}
	return db, runtimeDialectPostgres, nil
}

func normalizePostgresDSN(dsn string) string {
	s := strings.TrimSpace(dsn)
	low := strings.ToLower(s)
	if !(strings.HasPrefix(low, "postgresql://") || strings.HasPrefix(low, "postgres://")) {
		// Already a libpq keyword/value string; pgx can parse it.
		return s
	}

	// If the password includes '@' (unescaped), URL parsing often "succeeds" but the host/port becomes invalid.
	// Also, if there are multiple '@' characters after the scheme, it's almost certainly that case.
	rest := s
	if i := strings.Index(rest, "://"); i != -1 {
		rest = rest[i+3:]
	}
	if strings.Count(rest, "@") > 1 {
		return fallbackURLToLibpqDSN(s)
	}

	// Happy path: valid URL *and* host/port are valid
	if u, err := url.Parse(s); err == nil {
		if hostPortLooksValid(u.Host) {
			return s
		}
	}

	// Fallback for common case: password contains '@' (or other chars) and is not URL-escaped.
	// We'll parse using the *last* '@' and build a libpq key=value DSN.
	return fallbackURLToLibpqDSN(s)
}

func hostPortLooksValid(hostport string) bool {
	hp := strings.TrimSpace(hostport)
	if hp == "" {
		return false
	}
	// If it has an explicit port, validate it parses as a real port.
	if strings.Contains(hp, ":") {
		host, port, err := net.SplitHostPort(hp)
		if err != nil || host == "" || port == "" {
			return false
		}
		pn, err := strconv.Atoi(port)
		if err != nil || pn <= 0 || pn > 65535 {
			return false
		}
	}
	return true
}

func fallbackURLToLibpqDSN(raw string) string {
	s := strings.TrimSpace(raw)
	// strip scheme
	i := strings.Index(s, "://")
	if i == -1 {
		return s
	}
	rest := s[i+3:]

	// split query
	q := ""
	if qi := strings.Index(rest, "?"); qi != -1 {
		q = rest[qi+1:]
		rest = rest[:qi]
	}

	// split userinfo and host/db using last '@'
	at := strings.LastIndex(rest, "@")
	if at == -1 {
		return raw
	}
	userInfo := rest[:at]
	hostAndPath := rest[at+1:]

	// user:password (password may contain ':', so split on first ':')
	user := userInfo
	pass := ""
	if ci := strings.Index(userInfo, ":"); ci != -1 {
		user = userInfo[:ci]
		pass = userInfo[ci+1:]
	}

	// host:port/dbname
	hostPort := hostAndPath
	dbName := ""
	if si := strings.Index(hostAndPath, "/"); si != -1 {
		hostPort = hostAndPath[:si]
		dbName = hostAndPath[si+1:]
	}

	host := hostPort
	port := ""
	if pi := strings.LastIndex(hostPort, ":"); pi != -1 {
		host = hostPort[:pi]
		port = hostPort[pi+1:]
	}

	sslmode := ""
	if q != "" {
		if vals, err := url.ParseQuery(q); err == nil {
			sslmode = vals.Get("sslmode")
		}
	}

	parts := []string{
		"host=" + libpqQuote(host),
	}
	if port != "" {
		parts = append(parts, "port="+libpqQuote(port))
	}
	if user != "" {
		parts = append(parts, "user="+libpqQuote(user))
	}
	if pass != "" {
		parts = append(parts, "password="+libpqQuote(pass))
	}
	if dbName != "" {
		parts = append(parts, "dbname="+libpqQuote(dbName))
	}
	if sslmode != "" {
		parts = append(parts, "sslmode="+libpqQuote(sslmode))
	}
	return strings.Join(parts, " ")
}

func libpqQuote(v string) string {
	// Always single-quote, escaping backslash and single quote.
	x := strings.ReplaceAll(v, `\`, `\\`)
	x = strings.ReplaceAll(x, `'`, `\'`)
	return "'" + x + "'"
}


