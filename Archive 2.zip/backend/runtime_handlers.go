package main

import (
	"database/sql"
	"encoding/json"
	"errors"
	"net/http"
	"strings"
	"time"

	"github.com/labstack/echo/v4"
)

func handlePublishWorkflow(c echo.Context) error {
	var req PublishWorkflowRequest
	if err := json.NewDecoder(c.Request().Body).Decode(&req); err != nil {
		return c.JSON(http.StatusBadRequest, PublishWorkflowResponse{Success: false, Error: "invalid request body"})
	}
	if req.Document.Schema != "hermes.workflow.v1" {
		return c.JSON(http.StatusBadRequest, PublishWorkflowResponse{Success: false, Error: "unsupported workflow schema"})
	}
	if len(req.Document.Graph.Nodes) == 0 {
		return c.JSON(http.StatusBadRequest, PublishWorkflowResponse{Success: false, Error: "workflow has no nodes"})
	}
	// Validate it's a linear chain (for now)
	if _, err := runtimeBuildLinearChain(req.Document); err != nil {
		return c.JSON(http.StatusBadRequest, PublishWorkflowResponse{Success: false, Error: err.Error()})
	}

	workflowID, err := runtimeInsertWorkflow(runtimeDB, runtimeDialect, req.Document)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, PublishWorkflowResponse{Success: false, Error: err.Error()})
	}
	publishedID, err := runtimeInsertPublication(runtimeDB, runtimeDialect, workflowID)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, PublishWorkflowResponse{Success: false, Error: err.Error()})
	}

	runnerPath := "/p/" + publishedID
	base := runnerBaseURL()
	runnerURL := ""
	if base != "" {
		runnerURL = base + runnerPath
	}

	return c.JSON(http.StatusOK, PublishWorkflowResponse{
		Success:      true,
		PublishedID:  publishedID,
		WorkflowID:   workflowID,
		RunnerPath:   runnerPath,
		RunnerURL:    runnerURL,
		DocumentEcho: &req.Document,
	})
}

func handleGetPublishedWorkflow(c echo.Context) error {
	publishedID := strings.TrimSpace(c.Param("publishedId"))
	if publishedID == "" {
		return c.JSON(http.StatusBadRequest, GetPublishedResponse{Success: false, Error: "publishedId is required"})
	}
	workflowID, doc, err := runtimeGetPublished(runtimeDB, runtimeDialect, publishedID)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return c.JSON(http.StatusNotFound, GetPublishedResponse{Success: false, Error: "published workflow not found"})
		}
		return c.JSON(http.StatusInternalServerError, GetPublishedResponse{Success: false, Error: err.Error()})
	}
	return c.JSON(http.StatusOK, GetPublishedResponse{
		Success:     true,
		PublishedID: publishedID,
		WorkflowID:  workflowID,
		Document:    doc,
	})
}

func handleStartPublishedWorkflow(c echo.Context) error {
	publishedID := strings.TrimSpace(c.Param("publishedId"))
	if publishedID == "" {
		return c.JSON(http.StatusBadRequest, StartRunResponse{Success: false, Error: "publishedId is required"})
	}

	var req StartRunRequest
	// Body optional
	_ = json.NewDecoder(c.Request().Body).Decode(&req)

	_, doc, err := runtimeGetPublished(runtimeDB, runtimeDialect, publishedID)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return c.JSON(http.StatusNotFound, StartRunResponse{Success: false, Error: "published workflow not found"})
		}
		return c.JSON(http.StatusInternalServerError, StartRunResponse{Success: false, Error: err.Error()})
	}

	chainIDs, err := runtimeBuildLinearChain(doc)
	if err != nil {
		return c.JSON(http.StatusBadRequest, StartRunResponse{Success: false, Error: err.Error()})
	}

	runID, err := runtimeInsertRun(runtimeDB, runtimeDialect, publishedID, chainIDs, req.InitialContext)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, StartRunResponse{Success: false, Error: err.Error()})
	}

	runRow, err := runtimeGetRun(runtimeDB, runtimeDialect, runID)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, StartRunResponse{Success: false, Error: err.Error()})
	}

	updatedRun, task, err := runtimeExecute(runRow, doc)
	if err != nil {
		// Mark failed
		_ = runtimeUpdateRun(runtimeDB, runtimeDialect, runID, RunStatusFailed, runRow.StepIndex, nil, runRow.Context)
		return c.JSON(http.StatusInternalServerError, StartRunResponse{Success: false, Error: err.Error()})
	}

	return c.JSON(http.StatusOK, StartRunResponse{Success: true, Run: runtimeRunView(updatedRun, task)})
}

func handleGetRun(c echo.Context) error {
	runID := strings.TrimSpace(c.Param("runId"))
	if runID == "" {
		return c.JSON(http.StatusBadRequest, GetRunResponse{Success: false, Error: "runId is required"})
	}
	runRow, err := runtimeGetRun(runtimeDB, runtimeDialect, runID)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return c.JSON(http.StatusNotFound, GetRunResponse{Success: false, Error: "run not found"})
		}
		return c.JSON(http.StatusInternalServerError, GetRunResponse{Success: false, Error: err.Error()})
	}

	var task *runtimeTaskRow
	if runRow.WaitingTaskID != nil {
		t, err := runtimeGetTask(runtimeDB, runtimeDialect, *runRow.WaitingTaskID)
		if err == nil {
			task = &t
		}
	}

	return c.JSON(http.StatusOK, GetRunResponse{Success: true, Run: runtimeRunView(runRow, task)})
}

func handleSubmitHumanTask(c echo.Context) error {
	taskID := strings.TrimSpace(c.Param("taskId"))
	if taskID == "" {
		return c.JSON(http.StatusBadRequest, SubmitHumanTaskResponse{Success: false, Error: "taskId is required"})
	}
	var req SubmitHumanTaskRequest
	if err := json.NewDecoder(c.Request().Body).Decode(&req); err != nil {
		return c.JSON(http.StatusBadRequest, SubmitHumanTaskResponse{Success: false, Error: "invalid request body"})
	}

	taskRow, err := runtimeGetTask(runtimeDB, runtimeDialect, taskID)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return c.JSON(http.StatusNotFound, SubmitHumanTaskResponse{Success: false, Error: "task not found"})
		}
		return c.JSON(http.StatusInternalServerError, SubmitHumanTaskResponse{Success: false, Error: err.Error()})
	}
	if taskRow.Status == HumanTaskCompleted {
		// idempotent: return current run
		runRow, err := runtimeGetRun(runtimeDB, runtimeDialect, taskRow.RunID)
		if err != nil {
			return c.JSON(http.StatusInternalServerError, SubmitHumanTaskResponse{Success: false, Error: err.Error()})
		}
		return c.JSON(http.StatusOK, SubmitHumanTaskResponse{Success: true, Run: runtimeRunView(runRow, &taskRow)})
	}

	taskRow, err = runtimeCompleteTask(runtimeDB, runtimeDialect, taskID, req.Answers)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, SubmitHumanTaskResponse{Success: false, Error: err.Error()})
	}

	// Load run + doc, store answers into run context under "human"
	runRow, err := runtimeGetRun(runtimeDB, runtimeDialect, taskRow.RunID)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, SubmitHumanTaskResponse{Success: false, Error: err.Error()})
	}

	_, doc, err := runtimeGetPublished(runtimeDB, runtimeDialect, runRow.PublishedID)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, SubmitHumanTaskResponse{Success: false, Error: err.Error()})
	}

	if runRow.Context == nil {
		runRow.Context = map[string]any{}
	}
	// Append answers keyed by nodeId (so multiple human nodes are supported later)
	h, _ := runRow.Context["human"].(map[string]any)
	if h == nil {
		h = map[string]any{}
	}
	h[taskRow.NodeID] = taskRow.Answers
	runRow.Context["human"] = h

	// Advance past the human node we were waiting on.
	runRow.WaitingTaskID = nil
	runRow.Status = RunStatusRunning
	runRow.StepIndex = runRow.StepIndex + 1

	if err := runtimeUpdateRun(runtimeDB, runtimeDialect, runRow.ID, runRow.Status, runRow.StepIndex, nil, runRow.Context); err != nil {
		return c.JSON(http.StatusInternalServerError, SubmitHumanTaskResponse{Success: false, Error: err.Error()})
	}

	// Resume execution
	reloaded, err := runtimeGetRun(runtimeDB, runtimeDialect, runRow.ID)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, SubmitHumanTaskResponse{Success: false, Error: err.Error()})
	}

	updatedRun, nextTask, err := runtimeExecute(reloaded, doc)
	if err != nil {
		_ = runtimeUpdateRun(runtimeDB, runtimeDialect, runRow.ID, RunStatusFailed, reloaded.StepIndex, nil, reloaded.Context)
		return c.JSON(http.StatusInternalServerError, SubmitHumanTaskResponse{Success: false, Error: err.Error()})
	}

	// Return updated state (if it hit another human node, include that task)
	return c.JSON(http.StatusOK, SubmitHumanTaskResponse{Success: true, Run: runtimeRunView(updatedRun, nextTask)})
}

func runtimeRunView(r runtimeRunRow, task *runtimeTaskRow) RunView {
	var waiting *string
	if r.WaitingTaskID != nil {
		waiting = r.WaitingTaskID
	}
	view := RunView{
		ID:            r.ID,
		PublishedID:   r.PublishedID,
		Status:        r.Status,
		StepIndex:     r.StepIndex,
		ChainIDs:      r.ChainIDs,
		WaitingTaskID: waiting,
		Context:       r.Context,
		CreatedAt:     r.CreatedAt,
		UpdatedAt:     r.UpdatedAt,
	}
	if task != nil {
		view.WaitingTask = &HumanTaskView{
			ID:        task.ID,
			RunID:     task.RunID,
			NodeID:    task.NodeID,
			Status:    task.Status,
			Form:      task.Form,
			Answers:   task.Answers,
			CreatedAt: task.CreatedAt,
		}
	}
	// Ensure JSON times are stable
	view.CreatedAt = view.CreatedAt.UTC().Truncate(time.Millisecond)
	view.UpdatedAt = view.UpdatedAt.UTC().Truncate(time.Millisecond)
	return view
}


