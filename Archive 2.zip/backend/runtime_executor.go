package main

import (
	"fmt"
)

// runtimeBuildLinearChain enforces a single-start, single-end, non-branching linear chain.
func runtimeBuildLinearChain(doc WorkflowDocument) ([]string, error) {
	nodes := doc.Graph.Nodes
	edges := doc.Graph.Edges
	if len(nodes) == 0 {
		return nil, fmt.Errorf("workflow has no nodes")
	}

	inDegree := map[string]int{}
	out := map[string][]string{}
	nodeSet := map[string]bool{}
	for _, n := range nodes {
		nodeSet[n.ID] = true
		inDegree[n.ID] = 0
	}
	for _, e := range edges {
		if !nodeSet[e.Source] || !nodeSet[e.Target] {
			return nil, fmt.Errorf("edge references missing node")
		}
		inDegree[e.Target]++
		out[e.Source] = append(out[e.Source], e.Target)
	}

	var starts []string
	for id, deg := range inDegree {
		if deg == 0 {
			starts = append(starts, id)
		}
	}
	if len(starts) != 1 {
		return nil, fmt.Errorf("workflow must have exactly 1 start node (found %d)", len(starts))
	}

	start := starts[0]
	chain := []string{start}
	visited := map[string]bool{start: true}
	cur := start

	for {
		nexts := out[cur]
		if len(nexts) == 0 {
			// end node
			return chain, nil
		}
		if len(nexts) > 1 {
			return nil, fmt.Errorf("branches are not supported yet")
		}
		next := nexts[0]
		if visited[next] {
			return nil, fmt.Errorf("cycle detected")
		}
		visited[next] = true
		chain = append(chain, next)
		cur = next
	}
}

func nodeByID(doc WorkflowDocument) map[string]WorkflowNode {
	m := make(map[string]WorkflowNode, len(doc.Graph.Nodes))
	for _, n := range doc.Graph.Nodes {
		m[n.ID] = n
	}
	return m
}

// runtimeExecute advances the run until it either completes, fails, or hits a human node.
func runtimeExecute(run runtimeRunRow, doc WorkflowDocument) (runtimeRunRow, *runtimeTaskRow, error) {
	nByID := nodeByID(doc)
	if run.StepIndex < 0 || run.StepIndex > len(run.ChainIDs) {
		return runtimeRunRow{}, nil, fmt.Errorf("invalid run step index")
	}

	// Ensure context map exists
	if run.Context == nil {
		run.Context = map[string]any{}
	}

	for run.StepIndex < len(run.ChainIDs) {
		nodeID := run.ChainIDs[run.StepIndex]
		node, ok := nByID[nodeID]
		if !ok {
			return runtimeRunRow{}, nil, fmt.Errorf("missing node in document: %s", nodeID)
		}

		kind := stringsLower(node.Kind)
		if kind == "human" {
			// Create a pending task and pause
			form := map[string]any{}
			// We expect human node config to look like {form: {...}}
			if node.Config != nil {
				if f, ok := node.Config["form"].(map[string]any); ok {
					form = f
				}
			}
			taskID, err := runtimeInsertHumanTask(runtimeDB, runtimeDialect, run.ID, node.ID, form)
			if err != nil {
				return runtimeRunRow{}, nil, err
			}
			run.Status = RunStatusWaitingHuman
			run.WaitingTaskID = &taskID

			if err := runtimeUpdateRun(runtimeDB, runtimeDialect, run.ID, run.Status, run.StepIndex, run.WaitingTaskID, run.Context); err != nil {
				return runtimeRunRow{}, nil, err
			}
			updated, err := runtimeGetRun(runtimeDB, runtimeDialect, run.ID)
			if err != nil {
				return runtimeRunRow{}, nil, err
			}
			task, err := runtimeGetTask(runtimeDB, runtimeDialect, taskID)
			if err != nil {
				return runtimeRunRow{}, nil, err
			}
			return updated, &task, nil
		}

		// Non-human nodes auto-complete for now.
		run.StepIndex++
	}

	run.Status = RunStatusCompleted
	run.WaitingTaskID = nil
	if err := runtimeUpdateRun(runtimeDB, runtimeDialect, run.ID, run.Status, run.StepIndex, nil, run.Context); err != nil {
		return runtimeRunRow{}, nil, err
	}
	updated, err := runtimeGetRun(runtimeDB, runtimeDialect, run.ID)
	if err != nil {
		return runtimeRunRow{}, nil, err
	}
	return updated, nil, nil
}

func stringsLower(s string) string {
	// small helper to avoid importing strings everywhere we need a lower.
	b := []byte(s)
	for i, c := range b {
		if c >= 'A' && c <= 'Z' {
			b[i] = c + 32
		}
	}
	return string(b)
}


