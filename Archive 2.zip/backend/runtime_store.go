package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/google/uuid"
)

func runtimeEnsureSchema(db *sql.DB, dialect runtimeSQLDialect) error {
	tsType := "TIMESTAMP"
	if dialect == runtimeDialectPostgres {
		tsType = "TIMESTAMPTZ"
	}

	stmts := []string{
		fmt.Sprintf(`CREATE TABLE IF NOT EXISTS workflows (
			id TEXT PRIMARY KEY,
			document_json TEXT NOT NULL,
			created_at %s NOT NULL
		);`, tsType),
		fmt.Sprintf(`CREATE TABLE IF NOT EXISTS published_workflows (
			id TEXT PRIMARY KEY,
			workflow_id TEXT NOT NULL,
			created_at %s NOT NULL
		);`, tsType),
		fmt.Sprintf(`CREATE TABLE IF NOT EXISTS workflow_runs (
			id TEXT PRIMARY KEY,
			published_id TEXT NOT NULL,
			status TEXT NOT NULL,
			chain_json TEXT NOT NULL,
			step_index INTEGER NOT NULL,
			waiting_task_id TEXT,
			context_json TEXT NOT NULL,
			created_at %s NOT NULL,
			updated_at %s NOT NULL
		);`, tsType, tsType),
		fmt.Sprintf(`CREATE TABLE IF NOT EXISTS human_tasks (
			id TEXT PRIMARY KEY,
			run_id TEXT NOT NULL,
			node_id TEXT NOT NULL,
			status TEXT NOT NULL,
			form_json TEXT NOT NULL,
			answers_json TEXT NOT NULL,
			created_at %s NOT NULL,
			completed_at %s
		);`, tsType, tsType),
	}
	for _, s := range stmts {
		if _, err := db.Exec(s); err != nil {
			return err
		}
	}
	return nil
}

func newID(prefix string) string {
	return fmt.Sprintf("%s_%s", prefix, strings.ReplaceAll(uuid.NewString(), "-", ""))
}

func runtimePH(dialect runtimeSQLDialect, n int) string {
	if dialect == runtimeDialectPostgres {
		return fmt.Sprintf("$%d", n)
	}
	return "?"
}

func runtimeInsertWorkflow(db *sql.DB, dialect runtimeSQLDialect, doc WorkflowDocument) (workflowID string, err error) {
	workflowID = newID("wf")
	b, err := json.Marshal(doc)
	if err != nil {
		return "", err
	}
	q := fmt.Sprintf(
		`INSERT INTO workflows (id, document_json, created_at) VALUES (%s, %s, %s)`,
		runtimePH(dialect, 1),
		runtimePH(dialect, 2),
		runtimePH(dialect, 3),
	)
	_, err = db.Exec(
		q,
		workflowID,
		string(b),
		time.Now().UTC(),
	)
	if err != nil {
		return "", err
	}
	return workflowID, nil
}

func runtimeInsertPublication(db *sql.DB, dialect runtimeSQLDialect, workflowID string) (publishedID string, err error) {
	publishedID = newID("pub")
	q := fmt.Sprintf(
		`INSERT INTO published_workflows (id, workflow_id, created_at) VALUES (%s, %s, %s)`,
		runtimePH(dialect, 1),
		runtimePH(dialect, 2),
		runtimePH(dialect, 3),
	)
	_, err = db.Exec(
		q,
		publishedID,
		workflowID,
		time.Now().UTC(),
	)
	if err != nil {
		return "", err
	}
	return publishedID, nil
}

func runtimeGetPublished(db *sql.DB, dialect runtimeSQLDialect, publishedID string) (workflowID string, doc WorkflowDocument, err error) {
	var docJSON string
	q := fmt.Sprintf(
		`SELECT pw.workflow_id, w.document_json
		 FROM published_workflows pw
		 JOIN workflows w ON w.id = pw.workflow_id
		 WHERE pw.id = %s`,
		runtimePH(dialect, 1),
	)
	row := db.QueryRow(
		q,
		publishedID,
	)
	if err := row.Scan(&workflowID, &docJSON); err != nil {
		return "", WorkflowDocument{}, err
	}
	if err := json.Unmarshal([]byte(docJSON), &doc); err != nil {
		return "", WorkflowDocument{}, err
	}
	return workflowID, doc, nil
}

func runtimeInsertRun(db *sql.DB, dialect runtimeSQLDialect, publishedID string, chainIDs []string, initialContext map[string]any) (runID string, err error) {
	runID = newID("run")
	chainB, _ := json.Marshal(chainIDs)
	if initialContext == nil {
		initialContext = map[string]any{}
	}
	ctxB, _ := json.Marshal(initialContext)
	now := time.Now().UTC()
	q := fmt.Sprintf(
		`INSERT INTO workflow_runs (id, published_id, status, chain_json, step_index, waiting_task_id, context_json, created_at, updated_at)
		 VALUES (%s, %s, %s, %s, %s, NULL, %s, %s, %s)`,
		runtimePH(dialect, 1),
		runtimePH(dialect, 2),
		runtimePH(dialect, 3),
		runtimePH(dialect, 4),
		runtimePH(dialect, 5),
		runtimePH(dialect, 6),
		runtimePH(dialect, 7),
		runtimePH(dialect, 8),
	)
	_, err = db.Exec(
		q,
		runID,
		publishedID,
		string(RunStatusRunning),
		string(chainB),
		0,
		string(ctxB),
		now,
		now,
	)
	if err != nil {
		return "", err
	}
	return runID, nil
}

type runtimeRunRow struct {
	ID            string
	PublishedID   string
	Status        RunStatus
	ChainIDs      []string
	StepIndex     int
	WaitingTaskID *string
	Context       map[string]any
	CreatedAt     time.Time
	UpdatedAt     time.Time
}

func runtimeGetRun(db *sql.DB, dialect runtimeSQLDialect, runID string) (runtimeRunRow, error) {
	var chainJSON string
	var ctxJSON string
	var waiting sql.NullString
	q := fmt.Sprintf(
		`SELECT id, published_id, status, chain_json, step_index, waiting_task_id, context_json, created_at, updated_at
		 FROM workflow_runs WHERE id = %s`,
		runtimePH(dialect, 1),
	)
	row := db.QueryRow(
		q,
		runID,
	)
	var r runtimeRunRow
	if err := row.Scan(&r.ID, &r.PublishedID, &r.Status, &chainJSON, &r.StepIndex, &waiting, &ctxJSON, &r.CreatedAt, &r.UpdatedAt); err != nil {
		return runtimeRunRow{}, err
	}
	_ = json.Unmarshal([]byte(chainJSON), &r.ChainIDs)
	_ = json.Unmarshal([]byte(ctxJSON), &r.Context)
	if waiting.Valid && waiting.String != "" {
		r.WaitingTaskID = &waiting.String
	}
	return r, nil
}

func runtimeUpdateRun(db *sql.DB, dialect runtimeSQLDialect, runID string, status RunStatus, stepIndex int, waitingTaskID *string, context map[string]any) error {
	ctxB, _ := json.Marshal(context)
	now := time.Now().UTC()
	if waitingTaskID == nil {
		q := fmt.Sprintf(
			`UPDATE workflow_runs SET status = %s, step_index = %s, waiting_task_id = NULL, context_json = %s, updated_at = %s WHERE id = %s`,
			runtimePH(dialect, 1),
			runtimePH(dialect, 2),
			runtimePH(dialect, 3),
			runtimePH(dialect, 4),
			runtimePH(dialect, 5),
		)
		_, err := db.Exec(
			q,
			string(status),
			stepIndex,
			string(ctxB),
			now,
			runID,
		)
		return err
	}
	q := fmt.Sprintf(
		`UPDATE workflow_runs SET status = %s, step_index = %s, waiting_task_id = %s, context_json = %s, updated_at = %s WHERE id = %s`,
		runtimePH(dialect, 1),
		runtimePH(dialect, 2),
		runtimePH(dialect, 3),
		runtimePH(dialect, 4),
		runtimePH(dialect, 5),
		runtimePH(dialect, 6),
	)
	_, err := db.Exec(
		q,
		string(status),
		stepIndex,
		*waitingTaskID,
		string(ctxB),
		now,
		runID,
	)
	return err
}

func runtimeInsertHumanTask(db *sql.DB, dialect runtimeSQLDialect, runID, nodeID string, form map[string]any) (taskID string, err error) {
	taskID = newID("task")
	formB, _ := json.Marshal(form)
	answersB, _ := json.Marshal(map[string]any{})
	now := time.Now().UTC()
	q := fmt.Sprintf(
		`INSERT INTO human_tasks (id, run_id, node_id, status, form_json, answers_json, created_at, completed_at)
		 VALUES (%s, %s, %s, %s, %s, %s, %s, NULL)`,
		runtimePH(dialect, 1),
		runtimePH(dialect, 2),
		runtimePH(dialect, 3),
		runtimePH(dialect, 4),
		runtimePH(dialect, 5),
		runtimePH(dialect, 6),
		runtimePH(dialect, 7),
	)
	_, err = db.Exec(
		q,
		taskID,
		runID,
		nodeID,
		string(HumanTaskPending),
		string(formB),
		string(answersB),
		now,
	)
	if err != nil {
		return "", err
	}
	return taskID, nil
}

type runtimeTaskRow struct {
	ID        string
	RunID     string
	NodeID    string
	Status    HumanTaskStatus
	Form      map[string]any
	Answers   map[string]any
	CreatedAt time.Time
}

func runtimeGetTask(db *sql.DB, dialect runtimeSQLDialect, taskID string) (runtimeTaskRow, error) {
	var formJSON, answersJSON string
	q := fmt.Sprintf(
		`SELECT id, run_id, node_id, status, form_json, answers_json, created_at
		 FROM human_tasks WHERE id = %s`,
		runtimePH(dialect, 1),
	)
	row := db.QueryRow(
		q,
		taskID,
	)
	var t runtimeTaskRow
	if err := row.Scan(&t.ID, &t.RunID, &t.NodeID, &t.Status, &formJSON, &answersJSON, &t.CreatedAt); err != nil {
		return runtimeTaskRow{}, err
	}
	_ = json.Unmarshal([]byte(formJSON), &t.Form)
	_ = json.Unmarshal([]byte(answersJSON), &t.Answers)
	return t, nil
}

func runtimeCompleteTask(db *sql.DB, dialect runtimeSQLDialect, taskID string, answers map[string]any) (runtimeTaskRow, error) {
	if answers == nil {
		answers = map[string]any{}
	}
	answersB, _ := json.Marshal(answers)
	now := time.Now().UTC()
	q := fmt.Sprintf(
		`UPDATE human_tasks SET status = %s, answers_json = %s, completed_at = %s WHERE id = %s`,
		runtimePH(dialect, 1),
		runtimePH(dialect, 2),
		runtimePH(dialect, 3),
		runtimePH(dialect, 4),
	)
	_, err := db.Exec(
		q,
		string(HumanTaskCompleted),
		string(answersB),
		now,
		taskID,
	)
	if err != nil {
		return runtimeTaskRow{}, err
	}
	return runtimeGetTask(db, dialect, taskID)
}

func runnerBaseURL() string {
	// Optional: set this to your frontend base (e.g. http://localhost:5173)
	// so backend can return a full URL.
	return strings.TrimRight(os.Getenv("HERMES_RUNNER_BASE_URL"), "/")
}


