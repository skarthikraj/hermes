package main

import "time"

// WorkflowDocument is the persisted representation produced by the frontend.
// We keep it as opaque JSON for forward-compat, but define minimal shapes needed for runtime execution.

type WorkflowDocument struct {
	Schema   string                 `json:"schema"`
	Version  int                    `json:"version"`
	Metadata map[string]any         `json:"metadata,omitempty"`
	Graph    WorkflowGraph          `json:"graph"`
}

type WorkflowGraph struct {
	Nodes []WorkflowNode `json:"nodes"`
	Edges []WorkflowEdge `json:"edges"`
}

type WorkflowNode struct {
	ID       string         `json:"id"`
	Kind     string         `json:"kind"`     // dataSource|transform|output|human
	ToolType string         `json:"toolType"` // input|filter|calculate|output|human|...
	Label    string         `json:"label"`
	Position map[string]any `json:"position,omitempty"`
	Config   map[string]any `json:"config,omitempty"`
}

type WorkflowEdge struct {
	ID     string `json:"id"`
	Source string `json:"source"`
	Target string `json:"target"`
}

type PublishWorkflowRequest struct {
	Document WorkflowDocument `json:"document"`
}

type PublishWorkflowResponse struct {
	Success      bool           `json:"success"`
	PublishedID  string         `json:"publishedId,omitempty"`
	WorkflowID   string         `json:"workflowId,omitempty"`
	RunnerPath   string         `json:"runnerPath,omitempty"`
	RunnerURL    string         `json:"runnerUrl,omitempty"`
	Error        string         `json:"error,omitempty"`
	DocumentEcho *WorkflowDocument `json:"document,omitempty"`
}

type GetPublishedResponse struct {
	Success     bool            `json:"success"`
	PublishedID string          `json:"publishedId,omitempty"`
	WorkflowID  string          `json:"workflowId,omitempty"`
	Document    WorkflowDocument `json:"document,omitempty"`
	Error       string          `json:"error,omitempty"`
}

type StartRunRequest struct {
	InitialContext map[string]any `json:"initialContext,omitempty"`
}

type RunStatus string

const (
	RunStatusRunning      RunStatus = "running"
	RunStatusWaitingHuman RunStatus = "waiting_human"
	RunStatusCompleted    RunStatus = "completed"
	RunStatusFailed       RunStatus = "failed"
)

type HumanTaskStatus string

const (
	HumanTaskPending   HumanTaskStatus = "pending"
	HumanTaskCompleted HumanTaskStatus = "completed"
)

type RunView struct {
	ID            string            `json:"id"`
	PublishedID   string            `json:"publishedId"`
	Status        RunStatus          `json:"status"`
	StepIndex     int               `json:"stepIndex"`
	ChainIDs      []string          `json:"chainIds"`
	WaitingTaskID *string           `json:"waitingTaskId,omitempty"`
	Context       map[string]any    `json:"context,omitempty"`
	CreatedAt     time.Time         `json:"createdAt"`
	UpdatedAt     time.Time         `json:"updatedAt"`
	WaitingTask   *HumanTaskView    `json:"waitingTask,omitempty"`
}

type HumanTaskView struct {
	ID        string         `json:"id"`
	RunID     string         `json:"runId"`
	NodeID    string         `json:"nodeId"`
	Status    HumanTaskStatus `json:"status"`
	Form      map[string]any `json:"form"`
	Answers   map[string]any `json:"answers,omitempty"`
	CreatedAt time.Time      `json:"createdAt"`
}

type StartRunResponse struct {
	Success bool    `json:"success"`
	Run     RunView `json:"run,omitempty"`
	Error   string  `json:"error,omitempty"`
}

type GetRunResponse struct {
	Success bool    `json:"success"`
	Run     RunView `json:"run,omitempty"`
	Error   string  `json:"error,omitempty"`
}

type SubmitHumanTaskRequest struct {
	Answers map[string]any `json:"answers"`
}

type SubmitHumanTaskResponse struct {
	Success bool    `json:"success"`
	Run     RunView `json:"run,omitempty"`
	Error   string  `json:"error,omitempty"`
}


