import React, { useMemo, useState, useCallback, useEffect } from 'react';
import ReactFlow, {
  MiniMap,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  addEdge,
  Handle,
  Position,
  ReactFlowProvider,
  useReactFlow,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { Upload, Filter, Calculator, Play, Download, Undo2 } from 'lucide-react';
import { uploadFile, executeWorkflowApi, planCopilotApi } from './api.js';
import logo from '../logo.png';

const DRAG_TYPE = 'application/reactflow';
const WORKFLOW_STORAGE_KEY = 'hermes.workflow.v1.current';

function nodeKindFromReactFlowType(type) {
  // ReactFlow node `type` mirrors our "kind"
  return type;
}

function toolTypeFromNode(node) {
  if (node.type === 'dataSource') return 'input';
  if (node.type === 'output') return 'output';
  return node.data?.type || 'unknown';
}

function sanitizeConfigForStorage(value) {
  // Ensure we only store JSON-serializable config (no functions, no big runtime data).
  if (value == null) return value;
  try {
    return JSON.parse(JSON.stringify(value));
  } catch {
    return {};
  }
}

function buildWorkflowDocument(nodes, edges) {
  return {
    schema: 'hermes.workflow.v1',
    version: 1,
    metadata: {
      name: 'Project Hermes Workflow',
      updatedAt: new Date().toISOString(),
    },
    graph: {
      nodes: nodes.map((n) => ({
        id: n.id,
        kind: nodeKindFromReactFlowType(n.type),
        toolType: toolTypeFromNode(n),
        label: n.data?.label || n.data?.title || n.type,
        position: n.position,
        config:
          n.type === 'transform'
            ? sanitizeConfigForStorage(n.data?.config || {})
            : n.type === 'dataSource'
              ? sanitizeConfigForStorage({ fileName: n.data?.fileName || null })
              : n.type === 'output'
                ? sanitizeConfigForStorage({ format: 'csv' })
                : sanitizeConfigForStorage({}),
      })),
      edges: edges.map((e) => ({
        id: e.id,
        source: e.source,
        target: e.target,
      })),
    },
  };
}

function readStoredWorkflowDocument() {
  try {
    const raw = localStorage.getItem(WORKFLOW_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed?.schema !== 'hermes.workflow.v1') return null;
    return parsed;
  } catch {
    return null;
  }
}

// Alteryx-ish palette (MVP)
const PALETTE_TOOLS = [
  {
    kind: 'dataSource',
    toolType: 'input',
    label: 'Input Data',
    description: 'Load Excel/CSV into the workflow',
    icon: Upload,
  },
  {
    kind: 'transform',
    toolType: 'select',
    label: 'Select',
    description: 'Choose/rename columns (not executed yet)',
    icon: Calculator,
  },
  {
    kind: 'transform',
    toolType: 'filter',
    label: 'Filter',
    description: 'Keep rows by condition',
    icon: Filter,
    defaultConfig: { column: 'sales', operator: '>', value: '1000' },
  },
  {
    kind: 'transform',
    toolType: 'calculate',
    label: 'Formula',
    description: 'Create/modify a column',
    icon: Calculator,
    defaultConfig: {
      newColumn: 'total_revenue',
      expression: `"sales"::DOUBLE * "quantity"::DOUBLE`,
    },
  },
  {
    kind: 'transform',
    toolType: 'sort',
    label: 'Sort',
    description: 'Sort rows (not executed yet)',
    icon: Calculator,
  },
  {
    kind: 'transform',
    toolType: 'summarize',
    label: 'Summarize',
    description: 'Group + aggregate (not executed yet)',
    icon: Calculator,
  },
  {
    kind: 'output',
    toolType: 'output',
    label: 'Output Data',
    description: 'Download results as CSV',
    icon: Download,
  },
];

function Palette() {
  return (
    <div className="w-72 border-r bg-gray-50 p-3 overflow-auto">
      <div className="text-xs font-semibold text-gray-500 mb-2">PALETTE</div>
      <div className="space-y-2">
        {PALETTE_TOOLS.map((tool) => {
          const Icon = tool.icon;
          return (
            <div
              key={`${tool.kind}:${tool.toolType}`}
              className="cursor-grab active:cursor-grabbing rounded border bg-white p-3 shadow-sm hover:bg-gray-50"
              draggable
              onDragStart={(event) => {
                event.dataTransfer.setData(DRAG_TYPE, JSON.stringify(tool));
                event.dataTransfer.effectAllowed = 'move';
              }}
            >
              <div className="flex items-start gap-2">
                <Icon className="w-4 h-4 text-gray-700 mt-0.5" />
                <div className="min-w-0">
                  <div className="text-sm font-semibold">{tool.label}</div>
                  <div className="text-xs text-gray-600">{tool.description}</div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 text-xs text-gray-500">
        Drag a tool onto the canvas.
        <br />
        Connect nodes left → right like Alteryx.
      </div>
    </div>
  );
}

function makeId(prefix) {
  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function summarizeTransform(data) {
  const t = (data?.type || '').toLowerCase();
  const cfg = data?.config || {};
  if (t === 'filter') {
    const col = cfg.column || '(column)';
    const op = cfg.operator || '(op)';
    const val = cfg.value ?? '(value)';
    return `${col} ${op} ${val}`;
  }
  if (t === 'calculate') {
    const col = cfg.newColumn || '(new_column)';
    const expr = cfg.expression || '(expression)';
    return `${col} = ${expr}`;
  }
  return data?.description || '';
}

function NodeInspector({ selectedNode, sourceColumns, onUpdateNodeData }) {
  if (!selectedNode) {
    return (
      <div className="p-3 overflow-auto flex-1">
        <div className="text-xs font-semibold text-gray-500 mb-2">CONFIG</div>
        <div className="text-sm text-gray-600">
          Click a node to configure it.
        </div>
      </div>
    );
  }

  const node = selectedNode;
  const title = node.data?.label || node.type;

  if (node.type === 'dataSource') {
    const cols = sourceColumns.length ? sourceColumns.join(', ') : '—';
    return (
      <div className="p-3 overflow-auto flex-1">
        <div className="text-xs font-semibold text-gray-500 mb-2">CONFIG</div>
        <div className="text-sm font-semibold mb-2">{title}</div>
        <div className="text-xs text-gray-700">
          <div className="mb-1">
            <span className="font-semibold">File:</span>{' '}
            {node.data?.fileName || 'No file selected'}
          </div>
          <div className="mb-1">
            <span className="font-semibold">Rows:</span>{' '}
            {node.data?.rowCount ?? '—'}
          </div>
          <div className="mb-1">
            <span className="font-semibold">Columns:</span> {cols}
          </div>
        </div>
        <div className="mt-3 text-xs text-gray-500">
          Use the file picker inside the node to upload.
        </div>
      </div>
    );
  }

  if (node.type === 'output') {
    return (
      <div className="p-3 overflow-auto flex-1">
        <div className="text-xs font-semibold text-gray-500 mb-2">CONFIG</div>
        <div className="text-sm font-semibold mb-2">{title}</div>
        <div className="text-xs text-gray-700">
          Download is enabled after execution.
        </div>
      </div>
    );
  }

  // transform
  const t = (node.data?.type || '').toLowerCase();
  const cfg = node.data?.config || {};
  const allowedOps = ['=', '!=', '<>', '>', '>=', '<', '<=', 'LIKE', 'ILIKE'];

  if (t === 'filter') {
    const column = cfg.column || '';
    const operator = cfg.operator || '=';
    const value = cfg.value ?? '';
    return (
      <div className="p-3 overflow-auto flex-1">
        <div className="text-xs font-semibold text-gray-500 mb-2">CONFIG</div>
        <div className="text-sm font-semibold mb-2">{title}</div>

        <div className="space-y-3">
          <div>
            <div className="text-xs font-semibold text-gray-600 mb-1">
              Column
            </div>
            {sourceColumns.length > 0 ? (
              <select
                className="w-full rounded border p-2 text-sm"
                value={column}
                onChange={(e) => {
                  const next = { ...cfg, column: e.target.value };
                  onUpdateNodeData(node.id, {
                    config: next,
                    description: summarizeTransform({ ...node.data, config: next }),
                  });
                }}
              >
                <option value="" disabled>
                  Select a column…
                </option>
                {sourceColumns.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            ) : (
              <input
                className="w-full rounded border p-2 text-sm"
                placeholder="e.g. sales"
                value={column}
                onChange={(e) => {
                  const next = { ...cfg, column: e.target.value };
                  onUpdateNodeData(node.id, {
                    config: next,
                    description: summarizeTransform({ ...node.data, config: next }),
                  });
                }}
              />
            )}
          </div>

          <div>
            <div className="text-xs font-semibold text-gray-600 mb-1">
              Operator
            </div>
            <select
              className="w-full rounded border p-2 text-sm"
              value={operator}
              onChange={(e) => {
                const next = { ...cfg, operator: e.target.value };
                onUpdateNodeData(node.id, {
                  config: next,
                  description: summarizeTransform({ ...node.data, config: next }),
                });
              }}
            >
              {allowedOps.map((op) => (
                <option key={op} value={op}>
                  {op}
                </option>
              ))}
            </select>
            <div className="mt-1 text-[11px] text-gray-500">
              For LIKE/ILIKE, use % wildcards (e.g. %foo%).
            </div>
          </div>

          <div>
            <div className="text-xs font-semibold text-gray-600 mb-1">
              Value
            </div>
            <input
              className="w-full rounded border p-2 text-sm"
              placeholder="e.g. 1000"
              value={value}
              onChange={(e) => {
                const next = { ...cfg, value: e.target.value };
                onUpdateNodeData(node.id, {
                  config: next,
                  description: summarizeTransform({ ...node.data, config: next }),
                });
              }}
            />
          </div>
        </div>
      </div>
    );
  }

  if (t === 'calculate') {
    const newColumn = cfg.newColumn || '';
    const expression = cfg.expression || '';
    return (
      <div className="p-3 overflow-auto flex-1">
        <div className="text-xs font-semibold text-gray-500 mb-2">CONFIG</div>
        <div className="text-sm font-semibold mb-2">{title}</div>

        <div className="space-y-3">
          <div>
            <div className="text-xs font-semibold text-gray-600 mb-1">
              New column
            </div>
            <input
              className="w-full rounded border p-2 text-sm"
              placeholder="e.g. total_revenue"
              value={newColumn}
              onChange={(e) => {
                const next = { ...cfg, newColumn: e.target.value };
                onUpdateNodeData(node.id, {
                  config: next,
                  description: summarizeTransform({ ...node.data, config: next }),
                });
              }}
            />
          </div>

          <div>
            <div className="text-xs font-semibold text-gray-600 mb-1">
              Expression (DuckDB SQL)
            </div>
            <textarea
              className="w-full rounded border p-2 text-sm font-mono"
              rows={5}
              placeholder={`Example:\n"sales"::DOUBLE * "quantity"::DOUBLE`}
              value={expression}
              onChange={(e) => {
                const next = { ...cfg, expression: e.target.value };
                onUpdateNodeData(node.id, {
                  config: next,
                  description: summarizeTransform({ ...node.data, config: next }),
                });
              }}
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-3 overflow-auto flex-1">
      <div className="text-xs font-semibold text-gray-500 mb-2">CONFIG</div>
      <div className="text-sm font-semibold mb-2">{title}</div>
      <div className="text-xs text-gray-700">
        This tool is UI-only right now. Execution is supported for Filter and
        Formula only.
      </div>
    </div>
  );
}

function CopilotPanel({
  workflowDocument,
  availableTools,
  sourceColumns,
  canUndo,
  onUndo,
  onApplyActions,
}) {
  const [input, setInput] = useState('');
  const [isPlanning, setIsPlanning] = useState(false);
  const [error, setError] = useState(null);
  const [messages, setMessages] = useState([]);
  const [proposedPatch, setProposedPatch] = useState(null);

  const patchSummary = useMemo(() => {
    if (!proposedPatch?.actions || !Array.isArray(proposedPatch.actions)) return null;
    const actions = proposedPatch.actions;

    const added = actions
      .filter((a) => a?.type === 'add_node')
      .map((a) => a?.label || a?.toolType || a?.nodeKind)
      .filter(Boolean);

    const updated = actions.filter((a) => a?.type === 'update_node').length;
    const removed = actions.filter((a) => a?.type === 'remove_node').length;
    const connected = actions.filter((a) => a?.type === 'connect').length;

    // Try to produce a “layman” sentence.
    const parts = [];
    if (added.length) parts.push(`add ${added.join(', ')}`);
    if (connected) parts.push(`connect ${connected} step${connected === 1 ? '' : 's'}`);
    if (updated) parts.push(`update ${updated} step${updated === 1 ? '' : 's'}`);
    if (removed) parts.push(`remove ${removed} step${removed === 1 ? '' : 's'}`);

    if (parts.length === 0) return 'I’m ready to apply the workflow update.';
    return `I will ${parts.join(', ')}.`;
  }, [proposedPatch]);

  const send = async () => {
    const text = input.trim();
    if (!text) return;
    setError(null);
    setProposedPatch(null);
    setMessages((m) => [...m, { role: 'user', content: text }]);
    setInput('');
    setIsPlanning(true);
    try {
      const resp = await planCopilotApi({
        instruction: text,
        workflow: workflowDocument,
        availableTools,
        sourceColumns,
      });
      if (!resp?.success) {
        throw new Error(resp?.error || 'Copilot planning failed');
      }
      setProposedPatch(resp.patch);
      setMessages((m) => [...m, { role: 'assistant', content: 'Proposed workflow update ready. Review and Apply.' }]);
    } catch (e) {
      setError(e?.message || String(e));
      setMessages((m) => [...m, { role: 'assistant', content: 'I could not generate a valid plan. Check backend Azure OpenAI config.' }]);
    } finally {
      setIsPlanning(false);
    }
  };

  return (
    <div className="p-3 overflow-auto flex flex-col flex-1">
      <div className="text-xs font-semibold text-gray-500 mb-2">COPILOT</div>

      <div className="flex-1 min-h-0 overflow-auto space-y-2">
        {messages.length === 0 ? (
          <div className="text-sm text-gray-600">
            Tell me what to build (example: “Add Input, filter sales &gt; 3000, then output”).
          </div>
        ) : (
          messages.map((m, idx) => (
            <div
              key={idx}
              className={`text-xs rounded p-2 border ${
                m.role === 'user' ? 'bg-white' : 'bg-gray-100'
              }`}
            >
              <div className="font-semibold mb-1">
                {m.role === 'user' ? 'You' : 'Copilot'}
              </div>
              <div className="whitespace-pre-wrap">{m.content}</div>
            </div>
          ))
        )}
      </div>

      {error && (
        <div className="mt-2 text-xs text-red-700 bg-red-50 border border-red-200 rounded p-2">
          {error}
        </div>
      )}

      {proposedPatch?.actions && (
        <div className="mt-2 text-xs">
          <div className="font-semibold text-gray-700 mb-1">Proposed update</div>
          <div className="bg-white border rounded p-2 text-sm text-gray-800">
            {patchSummary || 'I’m ready to apply the workflow update.'}
          </div>
          <div className="flex gap-2 mt-2">
            <button
              className="px-3 py-2 rounded border border-[#fd5108] text-black bg-white hover:bg-[#fd5108]/10"
              onClick={() => {
                onApplyActions(proposedPatch.actions || []);
                setProposedPatch(null);
              }}
            >
              Apply
            </button>
            <button
              className="px-3 py-2 rounded border bg-white hover:bg-gray-50 disabled:text-gray-400 disabled:cursor-not-allowed"
              disabled={!canUndo}
              onClick={onUndo}
            >
              Undo
            </button>
          </div>
        </div>
      )}

      <div className="mt-3 flex gap-2">
        <textarea
          className="flex-1 rounded border p-2 text-sm"
          rows={3}
          placeholder="Describe the workflow change…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
              e.preventDefault();
              send();
            }
          }}
        />
        <button
          className="px-3 py-2 rounded border border-[#fd5108] text-black bg-white hover:bg-[#fd5108]/10 disabled:text-gray-400 disabled:border-gray-300 disabled:hover:bg-white disabled:cursor-not-allowed"
          disabled={isPlanning}
          onClick={send}
          title="Ctrl/Cmd+Enter"
        >
          {isPlanning ? '…' : 'Send'}
        </button>
      </div>

      <div className="mt-2 text-[11px] text-gray-500">
        Tip: Ctrl/Cmd+Enter to send.
      </div>
    </div>
  );
}

function RightSidebar({
  rightTab,
  setRightTab,
  selectedNode,
  sourceColumns,
  onUpdateNodeData,
  workflowDocument,
  availableTools,
  canUndo,
  onUndo,
  onApplyActions,
}) {
  return (
    <div className="w-80 border-l bg-gray-50 flex flex-col">
      <div className="flex border-b">
        <button
          className={`flex-1 px-3 py-2 text-sm ${
            rightTab === 'config' ? 'bg-white font-semibold' : 'hover:bg-gray-100'
          }`}
          onClick={() => setRightTab('config')}
        >
          Config
        </button>
        <button
          className={`flex-1 px-3 py-2 text-sm ${
            rightTab === 'copilot' ? 'bg-white font-semibold' : 'hover:bg-gray-100'
          }`}
          onClick={() => setRightTab('copilot')}
        >
          Copilot
        </button>
      </div>

      {rightTab === 'config' ? (
        <NodeInspector
          selectedNode={selectedNode}
          sourceColumns={sourceColumns}
          onUpdateNodeData={onUpdateNodeData}
        />
      ) : (
        <CopilotPanel
          workflowDocument={workflowDocument}
          availableTools={availableTools}
          sourceColumns={sourceColumns}
          canUndo={canUndo}
          onUndo={onUndo}
          onApplyActions={onApplyActions}
        />
      )}
    </div>
  );
}

// Custom Node Components
const DataSourceNode = ({ data }) => {
  return (
    <div className="w-[240px] h-[140px] px-4 py-3 shadow-lg rounded-lg bg-blue-50 border-2 border-blue-500 flex flex-col">
      <Handle type="source" position={Position.Right} className="w-3 h-3" />
      <div className="flex items-center gap-2 mb-2">
        <Upload className="w-4 h-4 text-blue-600" />
        <div className="font-bold text-sm">Data Source</div>
      </div>
      <div className="text-xs text-gray-600 flex-1 min-h-0">
        <div className="font-semibold truncate" title={data.fileName || ''}>
          {data.fileName || 'No file selected'}
        </div>
        {data.rowCount && <div className="mt-1">{data.rowCount} rows loaded</div>}
      </div>
      <input
        type="file"
        accept=".xlsx,.xls,.csv"
        onChange={data.onFileUpload}
        className="mt-2 text-xs w-full"
      />
    </div>
  );
};

const TransformNode = ({ data }) => {
  const summary = summarizeTransform(data);
  return (
    <div className="w-[240px] h-[140px] px-4 py-3 shadow-lg rounded-lg bg-green-50 border-2 border-green-500 flex flex-col">
      <Handle type="target" position={Position.Left} className="w-3 h-3" />
      <Handle type="source" position={Position.Right} className="w-3 h-3" />
      <div className="flex items-center gap-2 mb-2">
        {data.type === 'filter' ? (
          <Filter className="w-4 h-4 text-green-600" />
        ) : (
          <Calculator className="w-4 h-4 text-green-600" />
        )}
        <div className="font-bold text-sm truncate" title={data.label}>
          {data.label}
        </div>
      </div>
      <div className="text-xs text-gray-600 flex-1 min-h-0">
        <div className="line-clamp-2" title={summary}>
          {summary}
        </div>
        {data.rowCount && <div className="mt-1">{data.rowCount} rows</div>}
        {data.unsupported && (
          <div className="mt-1 text-amber-700">
            Not executable yet (UI only)
          </div>
        )}
      </div>
    </div>
  );
};

const OutputNode = ({ data }) => {
  return (
    <div className="w-[240px] h-[140px] px-4 py-3 shadow-lg rounded-lg bg-purple-50 border-2 border-purple-500 flex flex-col">
      <Handle type="target" position={Position.Left} className="w-3 h-3" />
      <div className="flex items-center gap-2 mb-2">
        <Download className="w-4 h-4 text-purple-600" />
        <div className="font-bold text-sm">Output</div>
      </div>
      <div className="text-xs text-gray-600 flex-1 min-h-0">
        {data.rowCount ? `${data.rowCount} rows` : 'Ready to export'}
      </div>
      {data.results && (
        <button
          onClick={data.onDownload}
          className="mt-2 px-2 py-1 bg-purple-500 text-white text-xs rounded hover:bg-purple-600"
        >
          Download Results
        </button>
      )}
    </div>
  );
};

const nodeTypes = {
  dataSource: DataSourceNode,
  transform: TransformNode,
  output: OutputNode,
};

function buildLinearChain(nodes, edges) {
  const nodeById = new Map(nodes.map((n) => [n.id, n]));
  const out = new Map();
  edges.forEach((e) => {
    if (!out.has(e.source)) out.set(e.source, []);
    out.get(e.source).push(e.target);
  });

  const source = nodes.find((n) => n.type === 'dataSource');
  const output = nodes.find((n) => n.type === 'output');
  if (!source) {
    return { error: 'Add an Input Data node first.' };
  }
  if (!output) {
    return { error: 'Add an Output Data node.' };
  }

  const chain = [source.id];
  const visited = new Set(chain);
  let cur = source.id;
  while (cur !== output.id) {
    const nexts = out.get(cur) || [];
    if (nexts.length === 0) {
      return { error: 'Connect your nodes from Input → … → Output.' };
    }
    if (nexts.length > 1) {
      return { error: 'Branches are not supported yet. Keep it linear for now.' };
    }
    const next = nexts[0];
    if (!nodeById.has(next)) {
      return { error: 'Found an edge to a missing node.' };
    }
    if (visited.has(next)) {
      return { error: 'Cycle detected. Workflows must be acyclic.' };
    }
    chain.push(next);
    visited.add(next);
    cur = next;
  }
  return { sourceId: source.id, outputId: output.id, chainIds: chain };
}

function transformationsFromChain(nodes, chainIds) {
  const nodeById = new Map(nodes.map((n) => [n.id, n]));
  const transformations = [];
  const unsupported = [];

  for (const id of chainIds) {
    const node = nodeById.get(id);
    if (!node) continue;
    if (node.type !== 'transform') continue;

    const t = (node.data?.type || '').toLowerCase();
    if (t === 'filter' || t === 'calculate') {
      transformations.push({
        type: t,
        config: node.data?.config || {},
        _nodeId: node.id,
      });
    } else {
      unsupported.push(node.data?.label || node.id);
    }
  }
  return { transformations, unsupported };
}

const WorkflowAppInner = () => {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [isExecuting, setIsExecuting] = useState(false);
  const [results, setResults] = useState(null);
  const [selectedNodeId, setSelectedNodeId] = useState(null);
  const [resultsLimit, setResultsLimit] = useState(50);
  const [resultsPanelHeight, setResultsPanelHeight] = useState(240);
  const [isResizingResults, setIsResizingResults] = useState(false);
  const [rightTab, setRightTab] = useState('config');
  const [undoStack, setUndoStack] = useState([]);
  const [redoStack, setRedoStack] = useState([]);
  const { screenToFlowPosition } = useReactFlow();

  const selectedNode = useMemo(
    () => nodes.find((n) => n.id === selectedNodeId) || null,
    [nodes, selectedNodeId]
  );

  const workflowDocument = useMemo(
    () => buildWorkflowDocument(nodes, edges),
    [nodes, edges]
  );

  const availableTools = useMemo(
    () =>
      PALETTE_TOOLS.map((t) => ({
        kind: t.kind,
        toolType: t.toolType,
        label: t.label,
        description: t.description,
      })),
    []
  );

  const sourceColumns = useMemo(() => {
    const src = nodes.find((n) => n.type === 'dataSource' && n.data?.fileData?.length);
    const firstRow = src?.data?.fileData?.[0];
    if (!firstRow) return [];
    return Object.keys(firstRow);
  }, [nodes]);

  useEffect(() => {
    // Load last workflow (if present)
    const stored = readStoredWorkflowDocument();
    if (!stored?.graph?.nodes || !stored?.graph?.edges) return;

    const hydratedNodes = stored.graph.nodes
      .map((dn) => {
        const kind = dn.kind;
        const id = dn.id;
        const position = dn.position || { x: 50, y: 150 };

        if (kind === 'dataSource') {
          return {
            id,
            type: 'dataSource',
            position,
            data: {
              label: dn.label || 'Input Data',
              fileName: dn.config?.fileName || null,
              rowCount: null,
              fileData: null,
              onFileUpload: (e) => handleFileUpload(id, e),
            },
          };
        }
        if (kind === 'output') {
          return {
            id,
            type: 'output',
            position,
            data: {
              label: dn.label || 'Output Data',
              rowCount: null,
              results: null,
              onDownload: handleDownload,
            },
          };
        }
        // transform
        const toolType = dn.toolType || 'filter';
        return {
          id,
          type: 'transform',
          position,
          data: {
            label: dn.label || 'Transform',
            description: dn.description || '',
            type: toolType,
            rowCount: null,
            config: dn.config || {},
            unsupported: toolType !== 'filter' && toolType !== 'calculate',
          },
        };
      })
      .filter(Boolean);

    const hydratedEdges = stored.graph.edges
      .map((de) => ({
        id: de.id,
        source: de.source,
        target: de.target,
        animated: true,
      }))
      .filter(Boolean);

    setNodes(hydratedNodes);
    setEdges(hydratedEdges);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    // Persist workflow document in browser
    try {
      localStorage.setItem(WORKFLOW_STORAGE_KEY, JSON.stringify(workflowDocument));
    } catch {
      // ignore storage failures
    }
  }, [workflowDocument]);

  const pushUndo = useCallback(() => {
    setUndoStack((s) => [...s, { nodes, edges }]);
    setRedoStack([]);
  }, [nodes, edges]);

  const undo = useCallback(() => {
    setUndoStack((s) => {
      if (s.length === 0) return s;
      const prev = s[s.length - 1];
      setRedoStack((r) => [...r, { nodes, edges }]);
      setNodes(prev.nodes);
      setEdges(prev.edges);
      setSelectedNodeId(null);
      setResults(null);
      return s.slice(0, -1);
    });
  }, [nodes, edges, setEdges, setNodes, setResults, setSelectedNodeId]);

  const onConnect = useCallback(
    (params) => {
      pushUndo();
      setEdges((eds) => addEdge({ ...params, animated: true }, eds));
    },
    [pushUndo, setEdges]
  );

  const onNodesChangeWithUndo = useCallback(
    (changes) => {
      // Track deletions via the built-in change stream (covers keyboard delete as well)
      if (changes?.some?.((c) => c.type === 'remove')) {
        pushUndo();
      }
      onNodesChange(changes);
    },
    [onNodesChange, pushUndo]
  );

  const onEdgesChangeWithUndo = useCallback(
    (changes) => {
      if (changes?.some?.((c) => c.type === 'remove')) {
        pushUndo();
      }
      onEdgesChange(changes);
    },
    [onEdgesChange, pushUndo]
  );

  const handleFileUpload = async (nodeId, event) => {
    const file = event.target.files[0];
    if (!file) return;

    try {
      const resp = await uploadFile(file);
      setNodes((nds) =>
        nds.map((node) => {
          if (node.id === nodeId) {
            return {
              ...node,
              data: {
                ...node.data,
                fileName: file.name,
                rowCount: resp.rowCount,
                fileData: resp.data
              },
            };
          }
          return node;
        })
      );
    } catch (err) {
      alert('Upload failed: ' + (err?.message || err));
    }
  };

  function handleDownload() {
    if (!results) return;

    const csv = [
      Object.keys(results[0]).join(','),
      ...results.map((row) => Object.values(row).join(',')),
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'workflow_results.csv';
    a.click();
  }

  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();
      const raw = event.dataTransfer.getData(DRAG_TYPE);
      if (!raw) return;

      let tool;
      try {
        tool = JSON.parse(raw);
      } catch {
        return;
      }

      const position = screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      });

      const id = makeId(tool.kind);
      if (tool.kind === 'dataSource') {
        pushUndo();
        setNodes((nds) => [
          ...nds,
          {
            id,
            type: 'dataSource',
            position,
            data: {
              label: tool.label,
              fileName: null,
              rowCount: null,
              fileData: null,
              onFileUpload: (e) => handleFileUpload(id, e),
            },
          },
        ]);
        return;
      }

      if (tool.kind === 'output') {
        pushUndo();
        setNodes((nds) => [
          ...nds,
          {
            id,
            type: 'output',
            position,
            data: {
              label: tool.label,
              rowCount: null,
              results: null,
              onDownload: handleDownload,
            },
          },
        ]);
        return;
      }

      // transform
      const initialConfig = tool.defaultConfig || {};
      pushUndo();
      setNodes((nds) => [
        ...nds,
        {
          id,
          type: 'transform',
          position,
          data: {
            label: tool.label,
            description: tool.description,
            type: tool.toolType,
            rowCount: null,
            config: initialConfig,
            unsupported: tool.toolType !== 'filter' && tool.toolType !== 'calculate',
          },
        },
      ]);
    },
    [handleDownload, handleFileUpload, pushUndo, screenToFlowPosition, setNodes]
  );

  const onUpdateNodeData = useCallback(
    (nodeId, patch) => {
      pushUndo();
      setNodes((nds) =>
        nds.map((n) => {
          if (n.id !== nodeId) return n;
          return { ...n, data: { ...n.data, ...patch } };
        })
      );
    },
    [pushUndo, setNodes]
  );

  const applyCopilotActions = useCallback(
    (actions) => {
      if (!Array.isArray(actions) || actions.length === 0) return;

      const refToId = {};
      let nextNodes = [...nodes];
      let nextEdges = [...edges];

      const resolve = (val) => {
        if (typeof val !== 'string') return null;
        if (val.startsWith('$')) return refToId[val] || null;
        return val;
      };

      const addNodeFromAction = (a, position) => {
        const id = a.nodeId || makeId(a.nodeKind || 'node');
        if (a.ref) refToId[a.ref] = id;

        if (a.nodeKind === 'dataSource') {
          nextNodes = nextNodes.concat({
            id,
            type: 'dataSource',
            position,
            data: {
              label: a.label || 'Input Data',
              fileName: null,
              rowCount: null,
              fileData: null,
              onFileUpload: (e) => handleFileUpload(id, e),
            },
          });
          return;
        }

        if (a.nodeKind === 'output') {
          nextNodes = nextNodes.concat({
            id,
            type: 'output',
            position,
            data: {
              label: a.label || 'Output Data',
              rowCount: null,
              results: null,
              onDownload: handleDownload,
            },
          });
          return;
        }

        // transform
        const toolType = a.toolType || 'filter';
        const config = a.config || {};
        nextNodes = nextNodes.concat({
          id,
          type: 'transform',
          position,
          data: {
            label: a.label || 'Transform',
            description: a.description || '',
            type: toolType,
            rowCount: null,
            config,
            unsupported: toolType !== 'filter' && toolType !== 'calculate',
          },
        });
      };

      actions.forEach((a) => {
        if (!a || typeof a !== 'object') return;
        const t = a.type;

        // Push one undo snapshot per copilot action (so Undo steps through changes)
        pushUndo();

        if (t === 'add_node') {
          const idx = nextNodes.length;
          const position = { x: 80 + idx * 300, y: 160 };
          addNodeFromAction(a, position);
          return;
        }

        if (t === 'update_node') {
          const nodeId = a.nodeId;
          const patch = a.patch || {};
          nextNodes = nextNodes.map((n) => {
            if (n.id !== nodeId) return n;
            const nextData = { ...n.data };
            if (patch.label) nextData.label = patch.label;
            if (n.type === 'transform' && patch.config) nextData.config = patch.config;
            return { ...n, data: nextData };
          });
          return;
        }

        if (t === 'remove_node') {
          const nodeId = a.nodeId;
          nextNodes = nextNodes.filter((n) => n.id !== nodeId);
          nextEdges = nextEdges.filter((e) => e.source !== nodeId && e.target !== nodeId);
          return;
        }

        if (t === 'connect') {
          const from = resolve(a.from);
          const to = resolve(a.to);
          if (!from || !to) return;
          nextEdges = nextEdges.concat({
            id: makeId('e'),
            source: from,
            target: to,
            animated: true,
          });
          return;
        }

        if (t === 'disconnect') {
          const edgeId = a.edgeId;
          nextEdges = nextEdges.filter((e) => e.id !== edgeId);
          return;
        }

        if (t === 'layout') {
          // simple left-to-right layout for a linear chain (if present)
          const chain = buildLinearChain(nextNodes, nextEdges);
          if (!chain.error) {
            const posById = new Map(
              chain.chainIds.map((id, i) => [id, { x: 80 + i * 300, y: 160 }])
            );
            nextNodes = nextNodes.map((n) => {
              const p = posById.get(n.id);
              return p ? { ...n, position: p } : n;
            });
          }
        }
      });

      setNodes(nextNodes);
      setEdges(nextEdges);
    },
    [edges, handleFileUpload, handleDownload, nodes, pushUndo, setEdges, setNodes]
  );

  const executeWorkflow = async () => {
    setIsExecuting(true);

    try {
      const chain = buildLinearChain(nodes, edges);
      if (chain.error) {
        alert(chain.error);
        setIsExecuting(false);
        return;
      }

      const sourceNode = nodes.find((n) => n.id === chain.sourceId);
      if (!sourceNode?.data?.fileData) {
        alert('Upload a file in the Input Data node first.');
        setIsExecuting(false);
        return;
      }

      const { transformations, unsupported } = transformationsFromChain(nodes, chain.chainIds);
      if (unsupported.length > 0) {
        alert(
          `These tools are UI-only for now and will be skipped on execution:\n- ${unsupported.join(
            '\n- '
          )}`
        );
      }

      const payload = {
        fileData: sourceNode.data.fileData,
        transformations: transformations.map((t) => ({
          type: t.type,
          config: t.config,
        })),
      };
      const resp = await executeWorkflowApi(payload);

      const rowCount = resp.rowCount || (resp.data ? resp.data.length : 0);
      setNodes((nds) =>
        nds.map((node) => {
          if (node.type === 'transform') {
            return { ...node, data: { ...node.data, rowCount } };
          }
          if (node.type === 'output') {
            return { ...node, data: { ...node.data, rowCount, results: resp.data } };
          }
          return node;
        })
      );
      setResults(resp.data);
      setResultsLimit(50);
    } catch (error) {
      alert('Error executing workflow: ' + error.message);
    } finally {
      setIsExecuting(false);
    }
  };

  useEffect(() => {
    if (!isResizingResults) return;

    let startY = 0;
    let startH = 0;

    const onMove = (e) => {
      // Dragging the handle UP increases height
      const dy = startY - e.clientY;
      const minH = 120;
      const maxH = Math.max(minH, Math.floor(window.innerHeight * 0.75));
      const next = Math.max(minH, Math.min(maxH, startH + dy));
      setResultsPanelHeight(next);
    };

    const onUp = () => {
      setIsResizingResults(false);
    };

    // We stash the start values on the window while resizing starts
    // (set in onPointerDown) to keep the effect logic simple.
    startY = window.__hermes_resultsResizeStartY || 0;
    startH = window.__hermes_resultsResizeStartH || resultsPanelHeight;

    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    window.addEventListener('mouseleave', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
      window.removeEventListener('mouseleave', onUp);
    };
  }, [isResizingResults, resultsPanelHeight]);

  return (
    <div className="w-full h-screen flex flex-col">
      <div className="bg-[#f6f7f8] text-gray-900 border-b p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img
            src={logo}
            alt="Project Hermes"
            className="w-14 h-14 object-contain"
          />
          <h1 className="text-xl font-bold">Project Hermes</h1>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={undo}
            disabled={undoStack.length === 0}
            className="flex items-center gap-2 px-4 py-2 rounded border bg-white hover:bg-gray-50 focus:outline-none focus:ring-0 disabled:border-gray-300 disabled:text-gray-400 disabled:hover:bg-white disabled:cursor-not-allowed"
          >
            <Undo2 className="w-4 h-4" />
            Undo
          </button>
          <button
            onClick={executeWorkflow}
            disabled={isExecuting}
            style={{ borderColor: '#fd5108' }}
            className="flex items-center gap-2 px-4 py-2 rounded border text-black bg-transparent hover:bg-[#fd5108]/10 focus:outline-none focus:ring-0 focus:border-[#fd5108] disabled:border-gray-300 disabled:text-gray-400 disabled:hover:bg-transparent disabled:cursor-not-allowed"
          >
            <Play className="w-4 h-4" />
            {isExecuting ? 'Executing...' : 'Run Workflow'}
          </button>
        </div>
      </div>
      
      <div className="flex-1 flex min-h-0">
        <Palette />
        <div className="flex-1" onDrop={onDrop} onDragOver={onDragOver}>
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChangeWithUndo}
            onEdgesChange={onEdgesChangeWithUndo}
            onConnect={onConnect}
            nodeTypes={nodeTypes}
            onNodeDragStart={() => pushUndo()}
            onSelectionDragStart={() => pushUndo()}
            onNodeClick={(_, node) => setSelectedNodeId(node.id)}
            onPaneClick={() => setSelectedNodeId(null)}
            fitView
          >
            <Controls />
            <MiniMap />
            <Background variant="dots" gap={12} size={1} />
          </ReactFlow>
        </div>
        <RightSidebar
          rightTab={rightTab}
          setRightTab={setRightTab}
          selectedNode={selectedNode}
          sourceColumns={sourceColumns}
          onUpdateNodeData={onUpdateNodeData}
          workflowDocument={workflowDocument}
          availableTools={availableTools}
          canUndo={undoStack.length > 0}
          onUndo={undo}
          onApplyActions={applyCopilotActions}
        />
      </div>

      {results && (
        <div
          className="bg-white border-t overflow-hidden flex flex-col"
          style={{ height: resultsPanelHeight }}
        >
          <div
            className="h-2 bg-gray-100 hover:bg-gray-200 cursor-row-resize select-none"
            title="Drag to resize"
            onMouseDown={(e) => {
              // Store start values for the resizing effect
              window.__hermes_resultsResizeStartY = e.clientY;
              window.__hermes_resultsResizeStartH = resultsPanelHeight;
              setIsResizingResults(true);
            }}
          />
          <div className="p-4 overflow-auto min-h-0">
          <div className="flex items-center justify-between gap-3 mb-2">
            <h3 className="font-bold">Results</h3>
            <div className="flex items-center gap-2 text-xs">
              <div className="text-gray-600">
                Showing{' '}
                <span className="font-semibold">
                  {Math.min(results.length, resultsLimit === Infinity ? results.length : resultsLimit)}
                </span>{' '}
                of <span className="font-semibold">{results.length}</span>
              </div>
              <button
                onClick={() => setResultsLimit(50)}
                className="px-2 py-1 rounded border bg-white hover:bg-gray-50"
                disabled={resultsLimit === 50}
              >
                50
              </button>
              <button
                onClick={() => setResultsLimit(200)}
                className="px-2 py-1 rounded border bg-white hover:bg-gray-50"
                disabled={resultsLimit === 200}
              >
                200
              </button>
              <button
                onClick={() => setResultsLimit(Infinity)}
                className="px-2 py-1 rounded border bg-white hover:bg-gray-50"
                disabled={resultsLimit === Infinity}
              >
                All
              </button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-xs">
              <thead>
                <tr className="bg-gray-100">
                  {results.length > 0 &&
                    Object.keys(results[0]).map((key) => (
                      <th key={key} className="px-2 py-1 text-left">
                        {key}
                      </th>
                    ))}
                </tr>
              </thead>
              <tbody>
                {results
                  .slice(0, resultsLimit === Infinity ? results.length : resultsLimit)
                  .map((row, idx) => (
                  <tr key={idx} className="border-b">
                    {Object.values(row).map((val, i) => (
                      <td key={i} className="px-2 py-1">{val}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          </div>
        </div>
      )}
    </div>
  );
};

const WorkflowApp = () => (
  <ReactFlowProvider>
    <WorkflowAppInner />
  </ReactFlowProvider>
);

export default WorkflowApp;


